package com.example.fitnessprogram

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fitnessprogram.adapter.ProgramAdapter
import com.example.fitnessprogram.databinding.ActivityMainBinding
import com.example.fitnessprogram.db.AppDatabase
import com.example.fitnessprogram.db.programList
import com.example.fitnessprogram.model.Program

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var appDatabase: AppDatabase
    private lateinit var programAdapter: ProgramAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appDatabase = AppDatabase(this)
        programAdapter = ProgramAdapter()

        initRv()

        programList().forEach {
            appDatabase.appDao().insertProgram(it)
        }

        programAdapter.setProgramList(appDatabase.appDao().getAllProgram())

        programAdapter.programOnClickListener = object : ProgramAdapter.ProgramOnClickListener {
            override fun onClick(program: Program) {
                if (program.programName == "Program") {
                    val intent = Intent(this@MainActivity,CreateProgramActivity::class.java)
                    startActivity(intent)
                } else {
                    val intent = Intent(this@MainActivity,ProgramActivity::class.java)
                    intent.putExtra("programName",program.programName)
                    startActivity(intent)
                }

            }

        }


    }

    private fun initRv() {
        binding.recyclerViewProgram.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            setHasFixedSize(true)
            adapter = programAdapter
        }
    }
}