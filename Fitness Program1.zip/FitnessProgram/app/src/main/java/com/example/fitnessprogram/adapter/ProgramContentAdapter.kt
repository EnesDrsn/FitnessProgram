package com.example.fitnessprogram.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fitnessprogram.R
import com.example.fitnessprogram.model.Program
import com.example.fitnessprogram.model.ProgramContent

class ProgramContentAdapter : RecyclerView.Adapter<ProgramContentAdapter.CityViewHolder>() {

    private val programContentList = arrayListOf<ProgramContent>()

    var programContentOnClickListener: ProgramContentOnClickListener? = null

    fun setProgramContentList(list: List<ProgramContent>) {
        programContentList.clear()
        programContentList.addAll(list)
        notifyDataSetChanged()
    }


    class CityViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val imageViewProgram: ImageView = itemView.findViewById(R.id.imageViewProgramContent)
        private val textViewProgram: TextView = itemView.findViewById(R.id.textViewProgramContent)


        fun bind(programContent: ProgramContent) {

            Glide.with(itemView.context)
                .load(ContextCompat.getDrawable(itemView.context, programContent.contentImage))
                .into(imageViewProgram)

            textViewProgram.text = programContent.contentName



        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CityViewHolder {
        return CityViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.program_content_view_holder, parent, false)
        )
    }

    override fun onBindViewHolder(holder: CityViewHolder, position: Int) {
        holder.bind(programContentList[position])

        holder.itemView.setOnClickListener {
            programContentOnClickListener?.onClick(programContentList[position])
        }

    }

    override fun getItemCount(): Int {
        return programContentList.size
    }

    interface ProgramContentOnClickListener {
        fun onClick(programContent: ProgramContent)
    }

}