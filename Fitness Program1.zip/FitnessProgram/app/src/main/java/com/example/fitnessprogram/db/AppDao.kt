package com.example.fitnessprogram.db

import androidx.room.*
import com.example.fitnessprogram.model.Program

@Dao
interface AppDao {
    @Query("SELECT * FROM Program")
    fun getAllProgram(): List<Program>

    @Query("SELECT * FROM Program WHERE programName=:programName")
    fun getQueryProgram(programName: String): Program
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertProgram(vararg program: Program)


}