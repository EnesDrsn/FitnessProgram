package com.example.fitnessprogram

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.fitnessprogram.databinding.ActivityProgramContentDetailBinding
import com.example.fitnessprogram.db.AppDatabase
import com.example.fitnessprogram.model.ProgramContent

class ProgramContentDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProgramContentDetailBinding

    private lateinit var appDatabase: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProgramContentDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val content = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("programContent",ProgramContent::class.java)
        } else {
            intent.getParcelableExtra("programContent")
        }!!

        appDatabase = AppDatabase(this)


        Glide.with(this)
            .load(ContextCompat.getDrawable(this, content.contentImage))
            .into(binding.imageViewContent)

        binding.textViewContentDetail.text = content.contentDetail


    }
}