package com.example.fitnessprogram.adapter

import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.fitnessprogram.R
import com.example.fitnessprogram.model.Program

class ProgramAdapter : RecyclerView.Adapter<ProgramAdapter.CityViewHolder>() {

    private val programList = arrayListOf<Program>()

    var programOnClickListener: ProgramOnClickListener? = null

    fun setProgramList(list: List<Program>) {
        programList.clear()
        programList.addAll(list)
        notifyDataSetChanged()
    }


    class CityViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val imageViewProgram: ImageView = itemView.findViewById(R.id.imageViewProgram)
        private val textViewProgram: TextView = itemView.findViewById(R.id.textViewProgram)


        fun bind(program: Program) {

            Glide.with(itemView.context)
                .load(ContextCompat.getDrawable(itemView.context, program.programImage))
                .into(imageViewProgram)

            textViewProgram.text = program.programName



        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CityViewHolder {
        return CityViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.program_view_holder, parent, false)
        )
    }

    override fun onBindViewHolder(holder: CityViewHolder, position: Int) {
        holder.bind(programList[position])

        holder.itemView.setOnClickListener {
            programOnClickListener?.onClick(programList[position])
        }



    }

    override fun getItemCount(): Int {
        return programList.size
    }

    interface ProgramOnClickListener {
        fun onClick(program: Program)
    }

}