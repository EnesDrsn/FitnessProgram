package com.example.fitnessprogram.model

import android.graphics.drawable.Drawable
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity
data class Program(
    @PrimaryKey
    val id: Int,
    val programName: String,
    val programImage: Int,
    val content: List<ProgramContent>
)
