package com.example.fitnessprogram.db

import com.example.fitnessprogram.R
import com.example.fitnessprogram.model.Program
import com.example.fitnessprogram.model.ProgramContent

fun programList(): List<Program> {


    val gogusContentDecline = ProgramContent(
        "Decline Dumbbell Fly",
        R.drawable.decline_dumbbel_flys_2,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1. Uygun ağırlıktaki dumbbell’ları seçip, ters eğimli mekik sehpası ya da ters eğimli bench sehpasına uzanın. \n" +
                "2. Ters eğimli mekik sehpasının, ayakları koyma yeri, egzersizi daha rahat yapmanızı sağlar. Aşağı kaymazsınız ve ayaklarınızı kastığınızda daha fazla ağırlık kaldırabilirsiniz. \n" +
                "3. Dumbbell’ları sırası ile kavrayıp kollarınızı açın. Dirsekleriniz hafif kırık vaziyette olacak. Göğsünüzün esnediğini hissedin. \n" +
                "4. Nefes alın ve ardından nefes vererek kollarınızı kapatmaya başlayın. Buradaki püf nokta ise kapatma anında göğsü sıkmak ve kolları yere dik olarak muhafaza etmektir. \n" +
                "5. Tepe noktasına ulaştığınızda bir saniye kadar bekleyin ve nefes alarak kaldırış hızınıza oranla daha yavaş bir hızda kollarınızı açmaya başlayın. \n" +
                "6. Kollarınız tamamen açıldığında nefes vererek tekrar kapatmaya başlayın.    \n"
    , arrayListOf("Alt Göğüs")
    )

    val gogusContentSinav = ProgramContent(
        "Şınav",
        R.drawable.sinav,
        arrayListOf("Evde ekipmansız", "spor salonu"),
        "1.\tYüzükoyun şekilde yere uzanın. Kollarınızı omuz genişliğinden biraz daha fazla açın. Parmak uçlarınıza basarak vücudunuz dümdüz olacak pozisyona gelin. (Bknz: İlk resim üst)\n" +
                "2.\tNefes alın ve dirseklerinizi kırarak kontrollü bir şekilde vücudunuz yere değmeye az bir mesafe kalana kadar yere inin. (Bknz: İlk resim alt)\n" +
                "3.\tYukarı doğru kalkarken nefes verin.\n" +
                "4.\tBu harekette püf nokta vücudunuzun ayaktan başa kadar düz bir çizgi halinde durmasıdır. Eğer bu doğrultuyu bozarsanız yük belinize binecek ve sakatlanmalara neden olacaktır.\n" +
                "5.\tŞınavın hızını ve inip kalkma mesafelerini aşağıdaki görsele yakın tutun. Hızlı tekrarlar ve mesafe kısalığı kendiniz kandırmaktan başka bir işe yaramaz.\n"
    , arrayListOf("Alt Göğüs")
    )
    val gogusContentFly = ProgramContent(
        "Dumbbell fly",
        R.drawable.dumbbell_fly,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tHareketi yapmanıza  engel olmayacak  ağırlıktaki dumbelları  her iki elinize birer adet alarak benche sırt üstü uzanın.\n" +
                "2.\tDumbbell‘ar  göğüs hizanızda, kollarınız dik ve avuç içleriniz birbirine bakar şekilde olacak. Bu başlangıç pozisyonunuz.\n" +
                "3.\tNefes alarak dumbell‘ları omuz hizasının biraz altına gelene kadar her iki yana dengeli olarak orta yavaş hızda indirin. Son noktada dumbell’lar üzerindeki hakimiyeti kaybetmemek için dirseklerinizi biraz bükebilirsiniz.\n" +
                "4.\tNefes vererek, dirseklerinizin açısını artırarak (kolları tam düz konuma getirerek) dumbbell’ları  göğüs hizasında yukarı kaldırın.\n" +
                "5.\tHareketin sonunda, dumbbell’ları birbirine değdirmeden, bir saniye kadar, göğüs kasını iyice kasarak izometrik çalışma yapın. Ardından tekrar inişe geçin.\n" +
                "6.\tKaldırma 2 saniye, indirme 3 saniye aralığı maksimum gelişimi sağlar. Bu egzersiz hızlı yapılırsa gelişim sağlanamaz.\n"
        , arrayListOf("Alt Göğüs")
    )

    val gogusContentChest = ProgramContent(
        "Chest Dips",
        R.drawable.chest_dips,
        arrayListOf("Evde ekipmansız", "spor salonu"),
        "1.\tÜst resimde görünen makine triceps dips makinesi ile aynıdır. Vücut açısı yere dik olursa arka kol kaslarınızı, vücut açısı yere 45° eğimle olursa alt göğüs kaslarınızı çalıştırırsınız.\n" +
                "2.\tŞınavın çok daha zor bir versiyonu diyebiliriz. Ayaklar yerden kesildiği için tüm yük göğüs kaslarına binecek ve en iyi gelişimi yakalayacaksınız.\n" +
                "3.\tMakinenin tutamaçlarını sıkıca kavrayın ve kendinizi yukarıya kaldırın. Başlangıç pozisyonu için bir kaç saniyeliğine dirseklerinizi kitleyebilirsiniz. Sadece set başlangıcında nefes kordinasyonunuzu ayarlayabilmek için bunu yapın.\n" +
                "4.\tNefes alarak, dirsek açınızı kapatmaya yani vücudunuzu aşağı indirmeye başlayın. 1,5 – 2 saniye aralığı uygun olacaktır. Bunu yaparken ayaklarınızı birbirine dolayın ve kalçanızı sıkarak ayaklarınızı geriye doğru uzatın.\n" +
                "5.\tBu sayede chest dips hareketi için gerekli açıyı yakalayacaksınız. Ayaklarınız ne kadar geriye gidip üst vücut yere doğru eğilmeye başlarsa yük arka kol kaslarınızdan alt göğüs kaslarınıza geçecektir.\n" +
                "6.\tDip noktaya kadar indikten sonra nefes vererek kuvvetlice kendinizi yukarı doğru itin. Tepe noktada dirseklerinizi kilitlemeden 1 saniye kadar bekleyip tekrar inişe başlayın\n"
        ,arrayListOf("Alt Göğüs"))

    val gogusContentSqueeze = ProgramContent(
        "Dumbbell Squeeze Press",
        R.drawable.dumbbell_squeeze_press,
        arrayListOf("sadece dumbell", "spor salonu"),
        "1.\tHer iki elinize birer dumbbell alarak  düz bench sehpasına uzanın.\n" +
                "2.\tAvuç içleriniz birbirine bakacak şekilde dumbbell’ları göğsünüzün hemen üstünde birleştirin. Bu başlangıç pozisyonunuz olacak.\n" +
                "3.\tNefes alın ve ardından nefes vererek kollarınız yere tam dik olacak şekilde dumbbelları kaldırın. İndirme ve kaldırma anında dumbbellar birbirine değecek.\n" +
                "4.\tNefes alarak dumbell’ları göğsünüze indirin.  Bu hareketi yaparken göğsünüzün iç kısmına konsantre olun.\n"
        ,arrayListOf("İç Göğüs"))

    val gogusContentDiamondSinav = ProgramContent(
        "Diamond Şınav", R.drawable.diamond_sinav,
        arrayListOf("Evde Ekipmansız"), "1-Ellerinizi  tamamen açın.\n" +
                "2- Baş parmaklarınızı ve işaret parmaklarınızı birleştirin. Diamond şınavda olması gereken el pozisyonu bu. Geri kalan her şey normal şınavla aynı olacak.\n"
        ,arrayListOf("İç Göğüs"))

    val gogusContentHammer = ProgramContent(
        "Hammer Press",
        R.drawable.hammer_press,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tUygun ağırlıkta iki dummbell seçip düz bench sehpasına uzanın. Bacaklarınız biraz açık ve ayak tabanınız yere tam bassın. Ağırlığı iterken buna ihtiyacınız olacak.\n" +
                "2.\tNormal dumbbell press egzersizinde ki gibi pozisyonunuzu alın fakat avuç içlerinizi birbirine bakar duruma getirin.\n" +
                "3.\tNefes alın ve ardından nefes vererek dumbbell’ları itmeye başlayın. Dumbbellar’ın birbirine değmesine bir santim kalana kadar devam edin.\n" +
                "4.\tBu kısım önemli; Egzersizin itiş anında sadece iç göğüs kasınıza odaklanın. Sonuna kadar kasılı tutun. Bunu yapmazsanız egzersizden %100 verim alamazsınız.\n" +
                "5.\tTepe noktaya ulaştığınızda kaldırış hızınıza oranla daha yavaş bir hızda, nefes alarak inişe geçin.\n" +
                "6.\tİniş anını ne kadar yavaş yaparsanız triceps (arka kol) kaslarınız ağırlığa daha fazla direnç göstereceği için o kadar fazla gelişir.\n" +
                "7.\tHızlı kalkış ve hızlı genişler kaslarınızı geliştirmez. Sadece gücünüzü tüketir.\n" +
                "8.\tSon noktaya kadar indiğinizde beklemeden tekrar kalkışa geçin.\n"
        ,arrayListOf("İç Göğüs"))

    val gogusContentCrossover = ProgramContent(
        "Cable Crossover",
        R.drawable.cable_crossove_making,
        arrayListOf("spor salonu"),
        "1.\tCable Cross makinesin’de makara guruplarını göğüs hizanızla aynı seviyeye çekin. Çok ağır olmayan bir ağırlık seçip tutamaçları sırasıyla tutun ve makineyi ortalayın. Ortaladıktan sonra kollarınız açık pozisyondayken bir adım kadar öne çıkın. Dengenizi sağlamak için bir ayağınızı geriye atabilirsiniz. Vücudunuzun üst kısmı mutlaka düz bir vaziyette olmalı.\n" +
                "2.\tNefes vererek açık pozisyonda ve yere paralel olan kollarınızı (bknz: ilk resim sol), kırmadan öne doğru kapatmaya başlayın. Hızınız orta bir hız olsun. Maksimum seviyede göğüs kaslarınıza odaklanın.  Kol ve omuz kaslarınızdan yardım almamaya çalışın.\n" +
                "3.\tElleriniz birbirine değip son noktaya geldiğinizde (bknz: ilk resim sağ) harekete devam edip eller birbirini geçer ve çapraz pozisyona getirirseniz Pectoralis major inner yani göğüs kaslarının iç kısmı daha çok çalışır ve göğüs kaslarınız arasında ki boşluğu doldurmak için fırsat yaratmış olursunuz.\n" +
                "4.\tNefes alarak sıkıştırma hızınıza göre daha düşük bir hızda kollarınızı kırmadan her iki yana açın.\n"
        ,arrayListOf("İç Göğüs"))

    val gogusContentLow = ProgramContent(
        "Low Cable Crossover",
        R.drawable.low_cable_crossover,
        arrayListOf("spor salonu"),
        "1.\tCablecross makinasının makaralarını el alta çekin. Uygun ağırlığı takın. Makineyi ortalayın ve kollarınızı serbest bırakın. Bu başlangıç pozisyonunuz olacak. Burada dikkat etmeniz gereken vücudun duruş şekli.\n" +
                "2.\tŞöyle anlatayım: Ayaklarınız yan yana durursa hareketi yapmanız zorlaşır, kaldırdığınız ağırlık miktarı azalır ve belinize bir yük biner. Eğer bir ayağınızı öne diğerini arkaya atarsanız hareketi yapmanız kolaylaşır ve göğüs kaslarınıza daha çok konsantre olabilirsiniz.\n" +
                "3.\tDiğer dikkat edilecek husus; bir ayağınız önde bir ayağınız arkada ağırlığı kaldırırken üst vücut ister istemez öne eğilecektir. Mümkün mertebe üst vücudu yere dik olarak tutun. Gerekirse ağırlık azaltın.\n" +
                "4.\tNefes alın ve ardından nefes vererek ağırlığı kaldırmaya başlayın. Bunu şu şekilde yapacaksınız. Kollar aşağıda serbest pozisyonda iken vücuda çarpmaması için açık vaziyette olur. Kapanış anında kollarınız yere dik ve birbirine bitişik hale gelecek.\n" +
                "5.\tSon noktaya geldiğinizde bir saniye kadar bekleyin ve kaldırış hızınıza oranla daha yavaş bir hızda nefes alarak kollarınızı aşağı doğru salın.\n"
        ,arrayListOf("Üst Göğüs"))

    val gogusContentIncline = ProgramContent(
        "incline dumbbell fly",
        R.drawable.incline_dumbbel_fly,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tArkası ayarlanabilir inçline bench sehpasını 40-60 derece aralığına getirin. Orta ağırlıkta iki dumbbell alıp sehpaya oturun, ağırlığı dizlerinizin üstüne koyun, sırtınızı sehpaya tam olarak dayadıktan sonra ağırlıkları yukarı kaldırın. Bu başlangıç pozisyonunuz olacak. (Bknz: İlk resim A)\n" +
                "2.\tBaşlangıç pozisyonundayken kollarınız yere 90 derecelik bir açı oluşturmalı ve avuç içleriniz birbirine bakmalı ve dumbbellar arasında bir kaç santim mesafe kalmalı.\n" +
                "3.\tNefes alarak kollarınızı yanlara doğru olabildiğince açın. Bunu yaparken göğüs kaslarınıza odaklanın. (Bknz: İlk resim B)\n" +
                "4.\tSon noktaya geldikten sonra nefes vererek kollarınızı yukarı kaldırın. Yine aynı şekilde kollar yere dik, tamamen düz ve dumbbell’lar arasında bir kaç santim mesafe kalmalı.\n" +
                "5.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Üst Göğüs"))
    val gogusContentPress = ProgramContent(
        "incline dumbbell press",
        R.drawable.incline_dumbbell_press,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tIncline bench sehpasını 60° açısına yakın bir açıya ayarlayın. Açı çok dik olursa ön omuz kasları, çok yatık olursa alt göğüs ve göğsün orta kısmı daha çok çalışacaktır. Üst göğüs kaslarınıza yoğunlaşacabileceğiniz en iyi açı 60° dir.  Sehpanın arka kısmında derece rakamları yok ise sabit incline barbell bench sehpasından kopya çekebilirsiniz.\n" +
                "2.\tİki adet dumbbell‘ı kavrayın ve bench’e uzanın. Ayaklarınızı bir omuz genişliği kadar açın ve egzersiz süresince yere tam basın. Bu size daha rahat bir itiş imkanı sunar.\n" +
                "3.\tNefes alın ve ardından nefes vererek 2 saniye aralığında, göğüs seviyenizdeki dumbbell’ları üst kolları yere dik tutarak, yukarı doğru itmeye başlayın.\n" +
                "4.\tTepe noktaya gelirken göğsünüzü iyice sıkın. Tepe noktada dumbbell‘ları birbirine değdirmemeye çalışın. Değme ya da çarpışma olursa bu dengenizi bozabilir.\n" +
                "5.\tTepe noktaya ulaşınca 1 saniye kadar bekleyip ardından nefes alarak 2 – 2,5 saniye aralığında dumbbell’ları indirmeye başlayın. Yine aynı şekilde üst kol yere dik olarak hareket edecek.\n" +
                "6.\tDip noktada ise göğüs kasınızın iyice esnediğini hissetmelisiniz. Dumbbell’ları ne kadar aşağı indirirseniz hareket çalışma mesafeniz o kadar artacak, kasınız daha çok çalışacaktır.\n"
        ,arrayListOf("Üst Göğüs") )

    val gogusContentBench = ProgramContent(
        "Dumbbell Bench Press",
        R.drawable.dumbbell_bench_press,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tBench üzerine yattığınızda dumbbell’ları yukarı kaldırın.  Kollarınız yere tamamen dik ve dumbbell’ların birbirine değmesine bir kaç santim mesafe kalmalı. Bu başlangıç pozisyonunuz olacak.\n" +
                "2.\tNefes alarak orta yavaş hızda dumbbell’ları 1,5 – 2 saniye aralığında indirmeye başlayın. Bunu yaparken ön kolların yere dik olarak inmesine dikkat edin. (Bknz: İlk resim sağ)\n" +
                "3.\tDip noktaya ulaştığınızda bekleme yapmadan nefes vererek 1 – 1.5 saniye aralığında dumbbell’ları kuvvetlice yukarı doğru itin.\n" +
                "4.\tTepe nokta ya ulaştığınızda (yine aynı şekilde dumbbell’lar arasında bir kaç cm mesafe kanala kadar) bekleme yapmadan nefes alarak orta yavaş hızda indirmeye başlayın.\n" +
                "5.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Üst Göğüs"))

    val gogusContentBenchPress = ProgramContent(
        "Bench Press",
        R.drawable.bench_press,
        arrayListOf("spor salonu"),
        "1-Bir Bench’e sırt üstu yatın. Bar’I omuz genişliğinden biraz daha geniş bir açıda, kollarınız düz olacak şekilde tutun.\n" +
                "2-Bar’I kontrollü bir şekilde göğsünüze kadar indirin. İndirirken dirseklerinizi vücudunuza yakın tutun. Bu en aşağıda dirsek ile vücudunuz arasında 45 derece açı oluşmasına yardımcı olur. En aşağıda 1 saniye boyunca durun, ve sonra Bar’I dümdüz yukarı başlangıç pozisyonuna doğru pressleyin.\n"
        ,arrayListOf("Üst Göğüs"))

    val gogusContentList = arrayListOf<ProgramContent>()
    gogusContentList.add(gogusContentDecline)
    gogusContentList.add(gogusContentSinav)
    gogusContentList.add(gogusContentFly)
    gogusContentList.add(gogusContentChest)
    gogusContentList.add(gogusContentSqueeze)
    gogusContentList.add(gogusContentDiamondSinav)
    gogusContentList.add(gogusContentHammer)
    gogusContentList.add(gogusContentCrossover)
    gogusContentList.add(gogusContentLow)
    gogusContentList.add(gogusContentIncline)
    gogusContentList.add(gogusContentPress)
    gogusContentList.add(gogusContentBench)
    gogusContentList.add(gogusContentBenchPress)


    val omuzContentList = arrayListOf<ProgramContent>()

    val omuzContentWeight = ProgramContent(
        "Weight Plate Front Raises",
        R.drawable.weight_plate,
        arrayListOf("spor salonu", "sadece dumbell", "evde ekipmansız"),
        "1.\tİki elinizle ağırlık plakasını yanlardan ya da üstten kavrayın. Bu egzersizi şahsen ön omuz amaçlı kullanmaktayım. 3 parçadan oluşan omuz kaslarını, parça parça çalıştırmak en iyi gelişimi sağlamaktadır.\n" +
                "2.\tPlakayı bel hizanızda tutun. Bu başlangıç pozisyonunuz olacak. Nefes alın ve ardından nefes vererek, dirseklerinizi kırmadan, plakayı kollarınız yere paralel oluncaya kadar kaldırın.\n" +
                "3.\tKimi varyasyonlarda bu mesafe aşılıp plaka kafa üstüne kadar kaldırılabiliyor. Bunu yapmak hareketi kolaylaştırır ve gelişimden çalar. Bu varyasyonu tercih etmeyin.\n" +
                "4.\tKollarınızı yere paralel olana kadar kaldırdıktan sonra iki saniye kadar bu pozisyonda kalın. Omuzlarınızın yandığını hissedin.\n" +
                "5.\tArdından nefes alarak kaldırış hızınıza oranla daha yavaş bir hızda indirmeye başlayın. Bu sayede iniş anında da ağırlığa karşı kaslar direnç gösterecek ve gelişmeye devam edecekler.\n" +
                "6.\tPlakayı belinize kadar yavaşça indirdikten sonra beklemeden tekrar kollarınız yere paralel oluncaya kadar kaldırın.\n"
        ,arrayListOf("Ön Omuz"))
    val omuzContentArnold = ProgramContent(
        "Arnold Press",
        R.drawable.arnold_dumbbell,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tArkası ayarlanabilir bench sehpahasını dik konuma getirip, sırtınızı iyice yaslayarak oturun. Ayaklarınız açık ve karşıya bakar konumda olursa yüksek ağırlıklarda dengenizi sağlamanıza yardımcı olur.\n" +
                "2.\tÜstten tutuşla her iki elinize birer dumbbell alın. Üst kollarınız birbirine paralel, yere dik ve avuç içleriniz vücudunuza bakar şekilde olmalı. (A)\n" +
                "3.\tNefes alın ve ardından nefes vererek, fleksiyon yaparak yani avuç içlerinizi dışarı doğru çevirerek (B), dumbbell’ları yukarı birbirlerine değmesine bir kaç santim mesafe kalana kadar kaldırın. (C)\n" +
                "4.\tTepe noktasında 0,5-1 saniye kadar bekledikten sonra, nefes alarak, kaldırış hızınıza oranla daha düşük bir hızda yine fleksiyon yaparak yani avuç içlerinizi vücudunuza çevirerek dumbell’ları aşağı indirip başlangıç pozisyonunuza gelin.\n"
        ,arrayListOf("Ön Omuz"))

    val omuzContentBarbell = ProgramContent(
        "Barbell shoulder press",
        R.drawable.barbell_shoulder,
        arrayListOf("spor salonu"),
        "1.\tAyaklarınızı bir omuz genişliği kadar açın. Uygun ağırlıkları taktığınız barbell’i omuz genişliğinizden yaklaşık bir karış kadar daha fazla ölçüde üstten tutuşla kavrayın. Barbell’i hızla yerden kesip köprücük kemiklerinizin üstüne alın ve dengenizi sağlayın. (Bknz: Resim 2 sol)\n" +
                "2.\tNefes alın ve ardından nefes vererek köprücük kemiğinize aldığınız barbell’i kuvvetlice yukarı doğru itin. Yine aynı şekilde tepe noktasına geldiğiniz de kol eklemlerinizi kitlemeyin.\n" +
                "3.\tBir saniye kadar bekledikten sonra nefes alarak, kaldırış hızınıza göre daha yavaş bir hızla barbell’i aşağı doğru indirin.Köprücük kemiğinize dayamadan tekrar kuvvetlice yukarı doğru itin.\n" +
                "4.\tTekrar sayısı kadar yapıp seti tamamlayın.\n"
        ,arrayListOf("Ön Omuz"))

    val omuzContentDumbbell = ProgramContent(
        "Dumbbell shoulder press(",
        R.drawable.dumbell_shoulder_oturarak,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tDerecesi ayarlanabilir bench sehpasını tam dik konuma getirin. Oturduğunuzda belinizin sehpaya tam olarak yaslandığından emin olun. Bu şekilde sakatlanmalardan korunmuş olursunuz.\n" +
                "2.\tHer iki elinize birer dumbbell alın. Dumbbell’ı yerden alırken önce dizlerinize oradan diz ile iktirip kafa hizanıza kadar kaldırabilirsiniz. Yüksek ağırlıklar kullanırken diz ile dumbbell’a vereceğiniz ivme başlangıç pozisyonuna geçmenizi kolaylaştıracaktır.\n" +
                "3.\tHer iki elinize aldığınız dumbbell’ı kafa ile boyun arasında bir hizada tutun. Bu başlangıç pozisyonunuz olacak. \n" +
                "4.\tNefes alın ve ardında nefes vererek dumbbellar’ı kuvvetlice yukarı doğru itin. Dumbbellar’ın birbirine değmesine bir kaç cm kadar mesafe kalmalı. \n" +
                "5.\tTepe noktaya ulaştıktan sonra nefes alarak, kaldırış hızınıza oranlar daha yavaş bir hızla başlangıç pozisyonunuza doğru indirin. Bir saniye kadar bekleyip tekrar kaldırın.\n"
        ,arrayListOf("Ön Omuz"))

    val omuzContentRaise = ProgramContent(
        "Dumbbell front raise",
        R.drawable.dumbbell_front_raise,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tHer iki elinize orta ağırlıkta birer dumbbell alın. Avuç içleriniz vücuda bakar şekilde kavrama yapın. Ayaklarınız rahat bir kaldırış için omuz genişliğiniz kadar açık olsun.\n" +
                "2.\tNefes alın ve ardından nefes vererek, sadece omuz ekleminizi kullanarak, başlangıç için sağ ya da sol kolunuzu omuz hizanıza kadar 1 – 1,5 saniye aralığında kaldırmaya başlayın.\n" +
                "3.\tTepe noktaya yani omuz hizanıza kadar ulaştıktan sonra  0,5 – 1 saniye kadar bekleyin ve ardından nefes alarak  1,5 – 2 saniye aralığında dumbbell’ı kolunuz yere dik olmasına yaklaşık 20 santim kalana kadar indirmeye başlayın.\n" +
                "4.\tKol hareketini tamamladıktan sonra bekleme yapmadan nefes vererek diğer kolu kaldırmaya başlayın ve yine aynı süre aralıkları ve aynı tepe noktası hizasına kadar kaldırıp, nefes vererek dip konuma geçin.\n" +
                "5.\tVücuda değmesine 20 santim kalmış ve bekleme konumunda olan kolunuzu nefes vererek tekrar kaldırın.\n"
        ,arrayListOf("Ön Omuz"))

    val omuzContentBarbellFront = ProgramContent(
        "Barbell front raise",
        R.drawable.barbell_front_raise_1,
        arrayListOf("spor salonu"),
        "1.\tAyaklarınızı bir omuz genişliği kadar açın ve dizlerinizi hafifçe kırıp kalçanızı biraz dışarı doğru itin. Bu sayede hareket boyunca yükün belinize binmesini engellemiş olacaksınız.\n" +
                "2.\tBarbell’i üstten tutuşla kavrayın. İki el arası mesafe omuz genişliğiniz kadar olsun. Bu harekette kapalı ya da açık tutuş yaparsanız ön omuz ile birlikte başka kasları devreye sokar hareketten çalarsınız. Örneğin açık tutuşla kanat kasları, kapalı tutuşla üst göğüs kasları negatif olacak çalışacaktır. Amacımız sadece ön omuz kasını çalıştırmak olduğundan bunu yapmanıza gerek yok.\n" +
                "3.\tKollarınız tamamen sarkık halde iken nefes alın ver ardından nefes vererek kollarınızı kaldırmaya başlayın. Üst ve ön kol düz bir çizgi halinde olmalı, dirseği bükmeyin.\n" +
                "4.\t1 – 1,5 saniye aralığında barbell baş seviyesine gelene kadar ağırlığı kaldırın.\n" +
                "5.\tTepe noktaya ulaştığınızda 1 saniye kadar bekleyin ve ardından nefes alarak 1,5 – 2 saniye aralığında ağırlığı indirmeye başlayın.\n"
        ,arrayListOf("Ön Omuz"))

    val omuzContentLateral = ProgramContent(
        "Lateral Raise",
        R.drawable.dumbbell_lateral_raise,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tHer iki elinize uygun ağırlıkta birer dumbbell alın. 5  ya da 7.5 kg ile başlayabilirsiniz. Gözünüze hafif gelmiş olabilir. Fakat egzersiz sonunda gücünüz tamamen tükenecek ve mükemmel bir gelişim ve pump hissi duyacaksınız. Bunun garantisini veriyorum.\n" +
                "2.\tAyaklarınızı omuz genişliğiniz kadar açın. Belinize ya da kalçanıza bir es vermenize gerek yok. Tamamen dik olarak durun. Kollarınız  lateral raise egzersizi boyunca vücudunuza paralel şekilde hareket edecek.\n" +
                "3.\tŞimdi nefes alın ve ardından nefes vererek  1,5 saniye aralığında kollarınızı omuz seviyenize kadar kaldırmaya başlayın. Dumbbell’lar yere paralel olarak hareket etmeli. Öne ya da arkaya herhangi bir eğim vermeyin.\n" +
                "4.\tOmuz hizasına yani tepe noktaya geldiğinizde 0,5 – 1 saniye kadar bekleyin ve ardından nefes alarak 2 saniye aralığında kolları aşağı indirmeye başlayın. İndirme ne kadar yavaş olursa ağırlığa karşı direnç o kadar fazla olur ve indirme anında da kas gelişimi devam eder.\n" +
                "5.\tDip noktaya geldiğinizde bekleme yapmadan nefes vererek tekrar kaldırmaya başlayın\n"
        ,arrayListOf("Orta Omuz"))

    val omuzContentMachine = ProgramContent(
        "Machine Lateral Raise",
        R.drawable.machine_lateral_raise,
        arrayListOf("spor salonu"),
        "1.\tÖncelikle oturma sehpasını ayarlayın ve çok yüksek olmayan bir ağırlık seçin.\n" +
                "2.\tMakineye oturun ve kolluklara, ön kollarınızı yere paralel ve vücuda dik olarak konumlandırın. Üst kollarınız ise vücut hizasında olsun. Öne ya da arkaya açı yaparlarsa orta omuz kasınızı izole bir şekilde çalıştıramazsınız.\n" +
                "3.\tNefes alın ve ardından nefes vererek 1 – 1,5 saniye aralığında üst kollarınız yere paralel oluncaya kadar kaldırın.\n" +
                "4.\tTepe noktaya gelince bir saniye kadar bekleyin ve ardından nefes alarak 1,5 – 2 saniye aralığında kollarınızı indirmeye başlayın. Dip noktaya indiğinizde bekleme yapmadan nefes vererek tekrar kaldırışa geçin.\n" +
                "5.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Orta Omuz"))

    val omuzContentUpright = ProgramContent(
        "Upright Row",
        R.drawable.upright_row,
        arrayListOf("spor salonu"),
        "1.\tAyaklarınızı omuz genişliğiniz kadar açın. Üst vücudunuzu yere dik olarak tutun. Bar’ı her iki elinizle omuz genişliği mesafesinde kavrayın.\n" +
                "2.\tBaşlangıç noktası için kollarınızı tamamen yere sarkıtın. Nefes alın ve ardından nefes vererek 1,5 saniye aralığında bar’ı köprücük kemiğinize, daha fazla çekebiliyorsanız çenenizin altına kadar çekin.\n" +
                "3.\tTepe noktada 1 saniye kadar bekleyin ve ardından nefes alarak 2 saniye aralığında bar’ı salmaya başlayın.\n" +
                "4.\tDip noktaya ulaştığınızda bekleme yapmadan tekrar çekişe başlayın\n"
        ,arrayListOf("Orta Omuz"))

    val omuzContentSide = ProgramContent(
        "Body Weight Side Lateral Raise",
        R.drawable.body_weight,
        arrayListOf("evde dekipmansız"),
        "1-Yani ön kol üzerinde ve ayak parmak uçlarımızda durduğumuz pozisyon. Kolumuzun altında yumuşak bir nesne bulunmalıdır yoksa dirseklerimizi sakatlayabiliriz.\n" +
                "2-Hareket için yükselirken yerde olan kolumuzu vücudumuzdan uzaklaştırmaya çalışmayacak, vücudumuzu yerde kalan kolumuzdan uzaklaştıracağız. \n" +
                "3-Yükseldiğimizde sırtımız yere dik pozisyona gelmelidir. Yere indiğimizde kolumuzun üzerine iyice inmeliyiz ki yan omuz kaslarımızda iyi bir gerilme oluşsun. \n" +
                "4-Sonra vücudumuzu kolumuzdan uzaklaştırarak tekrar yükselir ve gerekli sayıda hareketi tekrarlarız. Hareketi daha zorlaştırmak için boşta kalan elimizi belimize koyabiliriz.\n"
        ,arrayListOf("Orta Omuz"))

    val omuzContentFace = ProgramContent(
        "Face Pull",
        R.drawable.face_pull,
        arrayListOf("spor salonu"),
        "1.\tCablecross makinesine halatı takın. Makara gruplarını en yukarı kaldırın. Çekişi yukarıdan yüzünüze doğru yapacaksınız. O yüzden egzersizin ismi Face pull.\n" +
                "2.\tAvuç içleriniz içe bakacak şekilde halatı kavrayın. Makineden bir kaç adım uzaklaşın. Şimdi yapacağınız iki duruş şekli var. Bir tanesi ayaklar yan yana duruş, diğeri de bir ayak önde duruş şekli.\n" +
                "3.\tHer iki duruşunda kendine has özellikleri var. Bir ayak önde duruş hareketi daha kolay yapmanızı sağlarken arka omuza konsantre olmayı zorlaştırabiliyor.\n" +
                "4.\tAyaklar yana yana duruşta ise çekiş hareketini yapabilmek için vücudunuza geriye doğru bir açı vermeniz gerekiyor. Açıyı öyle bir ayarlamalısınız ki  vücut ağırlığınız kaldıracağınız kilodan çalmamış olsun. Her iki duruş şeklini de uygulayıp kendiniz karar verin.\n" +
                "5.\tDuruş şeklinizi ayarladıktan sonra. Nefes alın ve ardından nefes vererek  karşıya doğru uzattığınız halatı  yüzünüze doğru çekmeye başlayın.\n" +
                "6.\tAlnınıza doğru, yüzünüze doğru çekebilirsiniz. Milimetrik ayarlama yapmaya gerek yok. Sonuçta arka omuz kası sayesinde halatı yüzünüze doğru çekebiliyorsunuz.\n" +
                "7.\tSon noktaya geldiğinizde  bir saniye kadar bekleyin ve çekiş hızınıza oranla daha yavaş bir hızda  nefes alarak halatı salmaya başlayın\n"
        ,arrayListOf("Arka Omuz"))

    val omuzContentBent = ProgramContent(
        "Bent Over Lateral Raise",
        R.drawable.bent_over_lateral_raise,
        arrayListOf("spor salonu", "sadece dumbell"),
        "•\t1-Bacaklarınızı omuz hizanız kadar açın ve dizlerinizi biraz kırıp kalçanızı dışarı çıkartın. Bunu hareket boyunca beliniz ağrımasın diye yapacaksınız. Üst vücudunuzu olabildiğince yere paralel hale getirmeye çalışın. Kollarınızı aşağı sarkıtın.\n" +
                "•\t2-Nefes alın ve ardından nefes vererek her iki kolunuzu aynı anda geriye doğru kaldırmaya başlayın. 1-1,5 saniye aralığı uygun olacaktır.\n" +
                "•\t3-Kaldırabileceğiniz son nokta vücut hizanız olmalı. Daha fazla kaldırmaya çalışırsanız orta sırt kasları devreye girecektir. Amacınız sadece arka omuz kasını geliştirmekse vücut hizasına kadar kaldırdığınız anda beklemeye geçin 0,5 – 1 saniye aralığı kadar tepe noktada bekleyin.\n" +
                "•\t4-Ardından nefes alarak kolları aşağı 1,5 – 2 saniye aralığında salmaya başlayın.\n"
        ,arrayListOf("Arka Omuz"))

    val omuzContentReverse = ProgramContent(
        "Reverse Machine",
        R.drawable.reverse_machine,
        arrayListOf("spor salonu"),
        "1.\tYüzünüz makineye bakacak şekilde oturun, göğsünüzü reverse pec dec makinesinin pedine yaslayın. Üst vücudunuz yere dik pozisyonda olsun.\n" +
                "2.\tHer iki elinizi ileri uzatıp tutamaçları kavrayın. Dirseklerinizi çok az bükün.\n" +
                "3.\tNefes alın ve ardından nefes vererek 1,5 saniye aralığında kollarınızı geriye doğru açmaya başlayın. Kollar açıldıkça  dirsek bükümünüde azaltmaya başlayın\n" +
                "4.\tSon noktaya geldiğinizde kürek kemiklerinizi olabildiğince birbirine yaklaştırmaya çalışın. 1 saniye kadar bekleyin ve ardından nefes alarak 1,5-2 saniye aralığında kolları öne doğru yüke direnç göstererek salmaya başlayın.\n" +
                "5.\tKollar kapanınca bekleme yapmadan tekrar açmaya başlayın.\n"
        ,arrayListOf("Arka Omuz"))

    omuzContentList.add(omuzContentWeight)
    omuzContentList.add(omuzContentArnold)
    omuzContentList.add(omuzContentBarbell)
    omuzContentList.add(omuzContentDumbbell)
    omuzContentList.add(omuzContentRaise)
    omuzContentList.add(omuzContentBarbellFront)
    omuzContentList.add(omuzContentLateral)
    omuzContentList.add(omuzContentMachine)
    omuzContentList.add(omuzContentUpright)
    omuzContentList.add(omuzContentSide)
    omuzContentList.add(omuzContentFace)
    omuzContentList.add(omuzContentBent)
    omuzContentList.add(omuzContentReverse)

    val sirtContentList = arrayListOf<ProgramContent>()

    val sirtContentShrug = ProgramContent(
        "Dumbbell Shrug",
        R.drawable.dumbbell_shrugs,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tOrta-üst ağırlıkta iki adet dumbbell’ı ellerinize alıp aşağı doğru sarkık vaziyette durun. Avuç içleriniz vücudunuza bakacak şekilde olmalı.\n" +
                "2.\tEğer gireceğiniz ağırlık fazla ise dengenizi sağlayabilmeniz için ayak genişliğinizi, omuz genişliğinizin kadar açabilirsiniz. Hafif bir ağırlık ise ayaklarınız kapalı ya da yarı açık olabilir.\n" +
                "3.\tBurada dikkat edeceğiniz püf noktası ise hareketi yaparken sadece trapez kaslarınıza yoğunlaşmanızdır. Omuz ve kolları kesinlikle kullanmamaya çalışın.\n" +
                "4.\tNefes alın ve ardından nefes vererek her iki dumbbell’ı da trapez kaslarınızı kullanarak yukarı doğru çekin.  Ardından nefes alarak,  çekiş hızınıza oranla daha yavaş bir hızda aşağı doğru salın.\n" +
                "5.\tBu egzersizde tekrar sayısı yerine kasın yanmasına ve kasılmasına dikkat edin. Her kaldırışta trapez kaslarındaki pump etkisi biraz daha artacaktır. Zirveye ulaştığınızda set arası verin.\n"
        , arrayListOf("Trapez")
    )

    val sirtContentDeadlift = ProgramContent(
        "Deadlift",
        R.drawable.deadlift,
        arrayListOf("spor salonu"),
        "1.\tUygun ağırlıkları taktığınız barbell’i ayaklarınızın ucuna alın. Ayaklarınız omuz genişliğiniz kadar açık olsun ve parmak uçlarınız tam karşıya baksın.\n" +
                "2.\tBarbell alt bacaktaki kaval kemiğinize temas edecek kadar yakın olmalı. Bu pozisyonda alt bacağınız yere mümkün olduğunca dik, üst bacağınız yere 45 derece açıda olmalı.\n" +
                "3.\tÜst gövdeniz ise yere eğik ve üst bacağa 90 derece açıyı tamamlamalı. Bel – Sırt – Enseniz ise düz bir çizgi halinde olmalı.\n"
        , arrayListOf("Trapez","Orta Sırt","Bel"))

    val sirtContentBarbell = ProgramContent(
        "Barbell row",
        R.drawable.barbell_row,
        arrayListOf("spor salonu"),
        "1.\tAyaklarınızı bir omuz genişliği açıp parmak uçlarınızın tam karşıya baktığından emin olun. Dizlerinizi hafifçe kırın ve kalçayı biraz dışarı itin. Sırtınız yere yaklaşık  40-45 derece açıyla durmalı.\n" +
                "2.\tŞimdi uygun ağırlığı taktığınız barbell’i üstten tutuşla kavrayın. Elleriniz omuz genişliğiniz kadar açık olmalı. Avuç içlerinizin biri içeri, biri dışarı bakması ağırlığı daha iyi kavramanızı sağlayacaktır.\n" +
                "3.\tNefes alın ve ardından nefes vererek  kontrollü bir şekilde barbell’i karnınıza kadar çekin. 0,5 saniye kadar bekledikten sonra  nefes alarak kaldırış hızınıza göre daha yavaş bir hızda aşağı doğru salın.\n" +
                "4.\tDip noktaya ulaştığınızda bekleme yapmadan, nefes vererek tekrar yukarı çekin. Tekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        , arrayListOf("Kanat"))

    val sirtContentDumbbellRow = ProgramContent(
        "Dumbbell Row",
        R.drawable.one_dumbbell_row,
        arrayListOf("spor salonu", "sadece dumbell"),
        " \n" +
                "1.\tDüz bir bench’e sağ dizinizi ve sağ elinizi koyun. Sol elinizi yere, dumbbell’a doğru sarkıtın.  Burada en çok dikkat etmeniz gereken üst vücudunuzu yere paralel olarak tutmaktır. Bunu yaparsanız kanat kasınız maksimum verimde ve maksimum güçte çalışacaktır.\n" +
                "2.\tNefes alın ve ardından nefes vererek, uygun ağırlıkta seçtiğiniz dumbbell’i kontrollü bir şekilde orta hızda yukarı doğru çekin. Son noktaya geldiğinizde dirseğinizin dışarıya doğru açılmadığından emin olun. Üst kol ve ön kolunuz çekiş sırasında vücuda neredeyse bitişik bir şekilde hareket etmeli.\n" +
                "3.\tTepe noktasında bir saniye kadar bekledikten sonra nefes alarak orta yavaş bir hızda dumbbell’ı aşağı doğru salın.\n" +
                "4.\tKolunuz tamamen yere uzandığında bekleme yapmadan nefes vererek tekrar yukarı doğru çekin.\n" +
                "5.\tTekrar sayısı kadar yaptıktan sonra diğer kola geçin ve seti tamamlayın.\n"
        , arrayListOf("Kanat","Orta Sırt"))

    val sirtContentSeated = ProgramContent(
        "Seated Cable Row",
        R.drawable.seated_cable_row,
        arrayListOf("spor salonu"),
        "1.\tCable row makinesine V-bar ı takın, uygun bir ağırlık seçin ve makinenin sehpasına oturun.\n" +
                "2.\tOturuşu düzeltmeye ayaklardan başlayalım. Ayaklarınızı makinenin ayaklıklarına  koyun. Parmak uçları tam karşıya bakacak ve dizlerinizi hafifçe kıracaksınız. En çok yapılan hata dizleri kırmadan ayakları dayamaktır. Eğer bu şekilde yaparsanız ayaklarınızdan kuvvet almış olursunuz ve çekiş anında belinizi geriye atarak, sırtı değil bele yük bindirirsiniz. Bunu yapmamaya özen gösterin.\n" +
                "3.V-bar’ı iki elinizle kavrayıp kollarınızı öne doğru uzatın. Burada dikkat edilmesi gereken, kolları uzatıldığında üst vücudu tam dik konumda tutmaktır.\n" +
                "4.Nefes alın ve ardından nefesinizi vererek v-bar’ı kendinize doğru çekin. Son noktaya geldiğinizde kürek kemiklerinizi yapabildiğiniz kadar birbirine yaklaştırın. Bu sayede maksimum şekilde sırtınızı çalıştırmış olacaksınız.\n" +
                "5.Son noktada bir saniye kadar bekledikten sonra, çekiş hızınıza oranla daha yavaş bir hızda v-bar’ı salın. Bu sayede hareketin negatifinden de faydalanmış olursunuz.\n" +
                "6.Çekme ve salma yaparken kesinlikle vücudunuzu ileri – geri yatırmayın. Geriye doğru yatarsanız daha fazla yük kaldırabilirsiniz ama sırt kaslarını çalıştırmak yerine belinizi zorlamış olursunuz.\n"
        , arrayListOf("Kanat","Orta Sırt"))

    val sirtContentClose = ProgramContent(
        "Lat Pulldown",
        R.drawable.close_grip,
        arrayListOf("spor salonu"),
        "•\t1-V-bar’ı, Lat pulldown makinesine takın. Uygun bir ağırlık seçin. Makineye oturun ve dizlerinizi dizliklerin altına sokun. Makinenin kablosu göğsünüze hizalanana kadar makineye yaklaşın.\n" +
                "•\t2-Üst vücudunuz yere tamamen dik konumda olmalı. Daha fazla ağırlık çekebilmek için vücudunuzun üst kısmını geriye yatırmak gibi bir hata yapmayın. Sadece daha rahat çekmek için göğsünüzü ileri çıkartarak belinize biraz eğim verebilirsiniz\n" +
                "•\t3-Açık tutuşla barı kavrayın. Nefes vererek, orta hızda v-barı göğsünüzün üstüne değmesine bir kaç cm kalana kadar kontrollü bir şekilde çekin.\n" +
                "•\t4-Çekiş anında kürek kemiklerinizi sonuna kadar birbirine yaklaştırın ki hareket maksimum verimde olsun.\n" +
                "•\t5-Son noktaya geldiğinizde bir saniye kadar bekleyin ve nefes alarak v-barı orta hızda  yukarı doğru salın.\n" +
                "•\t6-Tekrar sayısı kadar yapıp seti tamamlayın.\n"
        , arrayListOf("Kanat","Orta Sırt"))

    val sirtContentLat = ProgramContent(
        "Close Grip Pulldown",
        R.drawable.lat_pulldown,
        arrayListOf("spor salonu"),
        "1.\tWide grip bar’ı lat pulldown makinesine takın. Uygun bir ağırlık seçin. El açıklığınız omuz genişliğinizden biraz daha fazla ve avuç içleri karşıya bakar şekilde barı kavrayın ve sehpaya oturun.\n" +
                "2.\tBacaklarınızı dizliklerin altına sokun. Dizlikler bacaklara mutlaka temas etmeli, arada boşluk kalmamalı. Şimdi çekişe başlayabiliriz.\n" +
                "3.\tÇekiş anında şuna dikkat etmelisiniz. Üst vücut mümkün olduğunca yere dik olarak kalmalı. Yani çekiş ve salış anlarında üst vücudu yatırıp kaldırarak çekişi kolaylaştırma amaçlı ivme kazanmayın. Çekişi sadece kanat kaslarınızı kullanarak yapmalısınız.\n" +
                "4.\tÜst resimde görüldüğü gibi üst vücut yere dik olarak çekişe başlamalı ve çekiş anında bel kısmına hafif bir es verilip göğüs ileri itilmeli, bar tam olarak üst göğüs üzerine çekilmelidir. Bunu daha rahat bir çekiş ve lat kaslarının range of motion’unu (kas uzama mesafesi – kas çalışma mesafesi) artırmak için yapıyoruz. Bu sayede daha çok esneyip, daha çok yırtılıp, daha çok gelişeceklerdir.\n" +
                "5.\tNefes vererek, her iki elinizle barı kavrayıp, barın göğsünüzün üst noktasına değmesine bir kaç cm mesafe kalana kadar, orta- yavaş bir hızda çekin.\n" +
                "6.\tSon noktaya geldiğinizde bir saniye kadar bekleyin ve nefes alarak barı orta- yavaş bir hızda yukarı doğru salın.\n" +
                "7.\tTekrar sayısı kadar yapıp seti tamamlayın.\n"
        , arrayListOf("Kanat") )

    val sirtContentBarfiks = ProgramContent(
        "Barfiks",
        R.drawable.barfiks,
        arrayListOf("spor salonu", "evde ekipmansız"),
        "1.\tBarfiks bar’ına ellerinizi omuz genişliğinizden biraz daha fazla mesafede avuç içleriniz karşıya bakacak şekilde tutunun.\n" +
                "2.\tNefes alın ve ardından nefes vererek,  başınız bar hizasını geçene kadar kendinizi yukarı doğru çekin.\n" +
                "3.\tHareketi uygularken ayaklarınızı sarkıtabilir ya da dizlerinizden kırabilirsiniz. (Dizlerden kırarak yapmak hareketi biraz daha konsantre hale getiriyor.)\n" +
                "4.\tSon noktaya ulaştıktan sonra nefes alarak, orta – yavaş bir hızda kendinizi kontrollü bir şekilde aşağı salın.\n" +
                "5.\tHareketi mümkün olduğu kadar sallanmadan, stabil bir şekilde uygulamaya gayret edin.\n"
        ,arrayListOf("Kanat","Orta Sırt") )

    val sirtContentMekik = ProgramContent(
        "Ters mekik",
        R.drawable.ters_mekik,
        arrayListOf("spor salonu", "evde ekipmansız"),
        "1.\tBir sehpaya yüzüstü yatın, ayak dayama ve karın dayama yerlerinin uygun ayarlandığından emin olun. Hareketten tam anlamıyla verim almak için kasıklarınız karın dayama yerine gelmeli.\n" +
                "2.\tPozisyonunuzu aldıktan sonra ilk resimde ki gibi vücudunuz tam düz olacak şekilde başlangıç pozisyonuna geçin.\n" +
                "3.\tNefes alarak üst gövdenizi 45 derecelik bir açı yaratıncaya kadar aşağıya indirin. Bir saniye kadar bekleyin ve nefes vererek başlangıç pozisyonuna dönün.\n" +
                "4.\tYukarı kalktığınızda 2 saniye kadar durun ve tekrar üst gövdenizi aşağı indirin. Set sayısı kadar yapıp hareketi tamamlayın.\n"
        ,arrayListOf("Bel","Orta Sırt") )


    sirtContentList.add(sirtContentShrug)
    sirtContentList.add(sirtContentDeadlift)
    sirtContentList.add(sirtContentBarbell)
    sirtContentList.add(sirtContentDumbbellRow)
    sirtContentList.add(sirtContentSeated)
    sirtContentList.add(sirtContentClose)
    sirtContentList.add(sirtContentLat)
    sirtContentList.add(sirtContentBarfiks)
    sirtContentList.add(sirtContentMekik)


    val onKolContentList = arrayListOf<ProgramContent>()

    val onKolContentHammer = ProgramContent(
        "Hammer Curl",
        R.drawable.hammer_curl,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tHer iki elinize orta ağırlıkta birer dumbbell alın. Avuç içleriniz birbirine bakar pozisyonda olsun.\n" +
                "2.\tAyaklarınızı bükmeden omuz genişliğiniz kadar açın. Dumbbell’lar bacaklarınıza hareket esnasında sürtmeyecek kadar bir mesafe olmalı.\n" +
                "3.\tHer iki kolunuz da yere sarkık pozisyonda iken nefes alın ve ardından nefes vererek tek kolunuzu kaldırmaya başlayın. Kaldırırken üst kolunuz sürekli yere dik ve vücuda temas halinde kalacak. Sadece ön kolunuz hareket edecek.\n" +
                "4.\tÖn kolunuzu 1 – 1,5 saniye aralığında maksimum şekilde yukarı kaldırın. Tepe noktaya ulaştığınızda 1 saniye kadar bekleyin.\n" +
                "5.\tArdından nefes alarak 1,5 – 2 saniye aralığında ön kolunuzu tamamen yere dik konuma gelene kadar sarkıtın.\n" +
                "6.\tBu maksimum kaldırma ve maksimum açma sayesinde ön kol kasınızın range of motion (kas uzama – çalışma) mesafesi en iyi seviyeye gelecek.\n" +
                "7.\tDip noktaya ulaştıktan sonra bekleme yapmadan nefes vererek diğer kola geçin ve aynı mesafe ve zaman aralığında kalkış ve inişi yapın.\n" +
                "8.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
    , arrayListOf("Ön Kol"))

    val onKolContentCable = ProgramContent(
        "Cable biceps curl",
        R.drawable.cable_biceps,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tMakinenin önünde durup çok ağır olmayan bir kilo takın.\n" +
                "2.\tUygun bir ağırlık seçin ve kollarınızı aşağı sarkıtıp başlangıç pozisyonunuza geçin. Elleriniz arasındaki boşluk omuz genişliğiniz kadar olsun. Bu şekilde biceps long ve short head eşit çalışır.\n" +
                "3.  Ayak duruşunu da iki şekilde yapabilirsiniz. Ayaklar yan yana olursa; daha fazla yüke girebilirsiniz ama bel problemi varsa zorlanabilir. Ayaklardan biri önde biri arkada olursa; bel korunur fakat kaldıracağınız ağırlık miktarı azalır. Her ikisini de deneyip kararınızı verin.\n" +
                "4.  Nefes alın ve ardından nefesinizi vererek 1 – 1,5 saniye aralığında barı çenenize değmesine bir kaç santim kalana kadar çekin.\n" +
                "5.  Tepe noktada 1 saniye kadar bekleyin ve ardından nefes alarak 1,5 – 2 saniye aralığında barı salarak kollarınızı tamamen açın. Kolu tamamen açmak ve maksimum kapatmak bu harekette oldukça önemli. Kas çekiş anında son noktaya kadar kısalıp, salış anında ise sonuna kadar uzamalı.\n" +
                "6.  Çekiş anında vücudunuzu sallayıp momentum kazanmayın. Mümkün mertebe sadece ön kollarınız hareket etsin.\n" +
                "7.\t Tekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Ön Kol"))

    val onKolContentConcentration = ProgramContent(
        "Concentration Curl",
        R.drawable.concentration_curl,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tBir bench’in kenarına oturun ve bacaklarınızı açın. Öne doğru biraz eğilin. Çalıştıracağınız kolunuzun dirseğini, aynı tarafa olan bacağınızın iç kısmına dayayın (üstüne değil, en çok yapılan hatalardan biri bu).\n" +
                "2.\tKolunuzu yere dik olacak şekilde sarkıtın. Bu başlangıç pozisyonunuz olacak. (Bknz resim A) Nefes alın ve ardından nefes vererek dumbbell’i sadece biceps kasınızı kullanarak 1 – 1,5 saniye aralığında yukarı kaldırın. (Bknz resim B)\n" +
                "3.\tSon noktaya (kol artık kapanamayacak kadar) ulaştığınız da  1 saniye kadar bekleyin ve nefes alarak, 1,5 – 2 saniye aralığında dumbbell’ı indirin. Bunu yapmanın amacı ise hareketin negatifi ile daha çok yırtılma sağlamaktır.\n" +
                "4.\tDip noktaya vardığınızda bekleme yapmadan nefes vererek tekrar kaldırmaya başlayın.\n" +
                "5.\tTekrar sayısı kadar yapıp tek kol setinizi tamamlayın ve diğer kola geçin.\n"
        ,arrayListOf("Ön Kol") )

    val onKolContentSeated = ProgramContent(
        "Concentration Curl",
        R.drawable.seated_dumbbell,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tBir bench’in ucuna üst vücudunuz tam dik olacak şekilde oturun. Her iki elinize birer dumbbell alarak avuç içleri vücudunuza dönük ve yere tam sarkık olarak tutun. (Bknz resim A) Rahat bir kaldırış için bacaklarınızı dumbbell’lar sürtmeyecek mesafede açın.\n" +
                "2.\tNefes alın ve ardından nefes vererek 1 – 1,5 saniye aralığında dumbbell’ı kaldırabildiğiniz son noktaya kadar kaldırın.\n" +
                "3.\tKaldırırken bileğinizi yukarı bakacak şekilde rotasyon yapın. (Bknz resim B) Tepe noktaya ulaştığınızda 1 saniye kadar bekleyin ve ardından nefes alarak 1,5 – 2 saniye aralığında dumbbell’ı aşağı sarkıtarak kolunuzu tam açın.\n" +
                "4.\tDip noktaya ulaştığınızda bekleme yapmadan, nefes vererek diğer kolunuzu kaldırmaya başlayın.\n" +
                "5.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Ön Kol"))

    val onKolContentBiceps = ProgramContent(
        "Biceps Curl Machine",
        R.drawable.biceps_machine,
        arrayListOf("spor salonu"),
        "1.\tMakineye oturun ve koltuk altlarınız makinenin yastığına tam oturacak şekilde pozisyon alın. Kalça kısmınızı da biraz geriye verin. Eğer yapabiliyorsanız bacaklarınızı makinenin alt demirlerine yaslayarak ön kollarınız hariç tüm vücudunuz sabit hale getirin. Bu sayede pump etkisini daha iyi hissedeceksiniz.\n" +
                "2.\tAğırlık kolunu sıkıca kavrayın. Nefes alın ve ardından nefes vererek, 1 – 1,5 saniye aralığında, tutamacı üst kollarınız yere dik oluncaya kadar kaldırın.\n" +
                "3.\tTepe noktaya geldiğinizde 1 saniye kadar bekleyin ve ardından nefes alarak 1,5 – 2 saniye aralığında kollarınızı açmaya başlayın.\n" +
                "4.\tDip noktaya ulaştığınızda kollarınız tamamen açık olmalı, biceps kasınızda gerginliği hissetmelisiniz. Dip noktaya ulaşınca bekleme yapmadan tekrar kaldırmaya geçin.\n" +
                "5.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Ön Kol") )

    val onKolContentBarbell = ProgramContent(
        "Barbell Curl",
        R.drawable.barbell_curl,
        arrayListOf("spor salonu"),
        "1.\tGenellikle başlangıç aşamasında çoğu kişi ayaklarını yan yana koyar. Fakat bizim tavsiyemiz, hareketin başlangıç aşamasında bir ayağınızın önde diğer ayağınızın arkada ve dizleriniz hafif bükülü olarak pozisyon almanızdır. Bunun nedeni ayakta ve aşağıdan yukarıya doğru yapılan bir harekette, en ufak bir dalgınlıkta bel omurlarınızı sakatlayabilirsiniz. Bu nedenle bir ayağınız önde ve diğer ayağınız arkada olacak şekilde ve dengenizi tam olarak sağladıktan sonra harekete başlamanızdır.\n" +
                "2.\tEğer ayaklarınız yan yana olacak şekilde hareketi uygulayacaksanız, üst gövdenizi hareket ettirmemeye çalışınız. Uygulama aşamasında üst gövdenizi çok hafif öne doğru eğmeniz yine bel omurlarınızın korunmasına yardımcı olacaktır.\n" +
                "3.\tBarı yukarıya doğru kaldırırken, mümkün olduğunda biceps kasınıza odaklanınız ve biceps kasınızı sıkmaya çalışınız. Barı aşağıya doğru indirirken, kontrollü bir şekilde ve biceps kasınızı gevşeterek indiriniz.\n"
        ,arrayListOf("Ön Kol"))

    onKolContentList.add(onKolContentHammer)
    onKolContentList.add(onKolContentCable)
    onKolContentList.add(onKolContentConcentration)
    onKolContentList.add(onKolContentSeated)
    onKolContentList.add(onKolContentBiceps)
    onKolContentList.add(onKolContentBarbell)

    val arkaKolContentList = arrayListOf<ProgramContent>()

    val arkaKolContentRope = ProgramContent(
        "Rope Pushdown",
        R.drawable.rope_pushdown,
        arrayListOf("spor salonu"),
        "1.\tTriceps istasyonu ya da cable cross makinesine halatı takın. Makara gruplarını en üste çekin (cable da yapacaksanız)\n" +
                "2.\tOrta bir ağırlık seçin. Vücudunuzu düz tutun. Üst resimdeki kadar mesafede makineye yaklaşın. Eğer yüksek bir ağırlık girecekseniz belinizi korumak için bir adım öne atabilir, ya da dizlere biraz açı verip kalçayı biraz geri itebilirsiniz.\n" +
                "3.\tHareket boyunca üst kollarınız (dirsek ve omuz arası) yere dik ve vücuda olabildiğince bitişik olacak.\n" +
                "4.\tNefes alın ve ardından nefesinizi vererek ön kollarınızı (el ve dirsek arası) yere paralel halden, aşağı doğru yere dik olana kadar, ellerinize fleksiyon vererek halatı itin. (fleksiyon : eklem hareketi)\n" +
                "5.\tÖn kollar yere tam dik olunca bekleme yapmadan, nefes alarak ve itiş hızınıza göre daha yavaş bir hızda halatı yukarı doğru salın.\n" +
                "6.\tÖn kollarınız yere paralel hale gelince salışı kesin ve bekleme yapmadan nefes vererek tekrar itişe geçin.\n" +
                "7.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
    ,arrayListOf("Arka Kol"))

    val arkaKolContentArm = ProgramContent(
        "One Arm Dumbbell Triceps Extension",
        R.drawable.arm,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tBir elinize kaldırabileceğiniz uygun ağırlıkta bir dumbbell alarak bench’e sırtınız dik olarak oturun. Dengeyi sağlamak için ayaklarınızı açabilirsiniz.\n" +
                "2.\tÇalıştıracağınız kolunuzu yere dik ve dumbbell’i en yukarıda olabilecek şekilde gergin olarak yukarı uzatın. Bu başlangıç pozisyonunuz olacak. (Bknz: İlk resim sağ)\n" +
                "3.\tNefes alarak, kolunuzu dirsekten kırarak dumbbell’i ensenize doğru orta – yavaş hızda indirin (Bknz: İlk resim sol).\n" +
                "4.\tDip noktaya geldiğinizde bekleme yapmadan nefes vererek dumbbell’ı yukarı doğru orta hızda kaldırmaya başlayın.\n" +
                "5.\tİniş ve kalkışlarda mümkün olduğu kadar üst kolunuzu sabit tutmaya çalışın. Sadece ön kolunuz hareket etsin.\n"
        ,arrayListOf("Arka Kol"))

    val arkaKolContentOverhead = ProgramContent(
        "Overhead Dumbbell Triceps Extension",
        R.drawable.overhead,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tBir bench’in üzerine oturun. Dengeyi sağlamak amaçlı ayaklarınızı açın. Uygun ağırlıkta bir dumbbel’ı her iki elinizle sıkıca kavrayıp başınızın arkasına alın. Bu başlangıç pozisyonunuz olacak.\n" +
                "2.\tDirsekleriniz ne çok açık ne de çok kapalı bir pozisyonda olsun. Nefes alın ve ardından nefes vererek triceps’lerinize odaklanarak dumbbell’ı yukarı doğru itin.\n" +
                "3.\tTepe noktasına geldiğiniz de bekleme yapmadan kaldırış hızınıza oranla biraz daha yavaş bir hızla, nefes alarak aşağıya doğru kontrollü bir şekilde indirin.\n" +
                "4.\tDip noktaya ulaştığınızda bekleme yapmadan tekrar kaldırışa geçin.\n" +
                "5.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Arka Kol") )

    val arkaKolContentPushdown = ProgramContent(
        "Triceps Pushdown",
        R.drawable.triceps_pushdow,
        arrayListOf("spor salonu"),
        "1.\tMakineye uygun ağırlık ve kısa triceps barı takılır.  Makara grubu en yükseğe kaldırılır. Eller arasında yaklaşık 20 cm mesafe kalacak şekilde ve avuç içleri aşağı bakacak pozisyonda bar kavranır.\n" +
                "2.\tOmuz ve dirsek arası yani üst kol yere dik ve vücuda mümkün olduğu kadar bitişik şekilde tutulur. Dirsek ve el arası yani ön kol yere paralel ya da biraz daha yukarıda duracak şekle getirilir. Bu başlangıç pozisyonudur.\n" +
                "3.\tİki çeşit ayak duruşu vardır. Birincisi : Bir ayak ileride ve vücut yükü onun üzerinde, diğer ayak biraz arkada ve parmak ucu yere basık topuk biraz kalkık, bel biraz eğik ve göğüs biraz ileride. İkincisi: Ayaklar aynı hizada ve yere tam basık, bel düz, göğüs biraz ileride.\n" +
                "4.\tBir ayağın önde olduğu pozisyon hareketi kolaylaştırır ve daha konsantre yapmanızı sağlar. Ayakların aynı hizada olduğu pozisyon ise  kasta ki gerçek yanmayı hissettirir ama hareketi yapması daha zordur. Her iki stilinde kendine göre avantajları vardır. Tercih sizin.\n" +
                "5.\tHazırsanız nefes alın ve ardından nefes vererek 1 – 1,5 saniye aralığında yere paralel olan ön kolunuzu, yere dik olana kadar indirmeye başlayın. Dip noktaya ulaştığınızda nefes alarak ön kolunuzu 1 – 1,5 saniye aralığında yere paralel (hatta biraz daha yukarı olabilir kasın tam olarak kendini salması için) olana kadar kaldırmaya başlayın.\n" +
                "6.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Arka Kol"))

    arkaKolContentList.add(arkaKolContentRope)
    arkaKolContentList.add(arkaKolContentArm)
    arkaKolContentList.add(arkaKolContentOverhead)
    arkaKolContentList.add(arkaKolContentPushdown)

    val bacakContentList = arrayListOf<ProgramContent>()

    val bacakContentGoblet = ProgramContent(
        "Goblet Squat",
        R.drawable.goblet_squat,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tAyaklarınızı standart gelişim için omuz mesafeniz kadar açın. Standart gelişimden kasıt bacak kaslarının iç ve dış kısımlarının eşit miktarda çalışmasıdır. İç kısmı daha fazla çalıştırmak isterseniz bacaklarınızı biraz daha açın. Dış kısmı daha fazla çalıştırmak isterseniz bacaklarınızı kapatın.\n" +
                "2.\tUygun ağırlıktaki dumbbellı tepe kısmından sağlam bir şekilde kavrayın ve çene hizanıza kadar kaldırın.\n" +
                "3.\tNefes alın ve ardından çömelmeye başlayın. Üst bacaklarınız yani dirsek ve kalça arası yere paralel olana kadar çömelin. Bu mesafeden aşağı inmenize gerek yok.  Çömelme anını yavaş yapın ki arka bacak kaslarınızda çalışsın. Hızlı yaparsanız emin olun goblet squat hareketinin yarısı boşa gitmiş olacak. Çömelme anı için ideal süre 2 saniyedir.\n" +
                "4.\tDip noktaya ulaştığınızda bekleme yapmadan nefes vererek 1 – 1,5 saniye aralığında ayaklarınız yere tamamen dik olana kadar kalkın.\n" +
                "5.\tTepe noktaya ulaştığınızda yine aynı şekilde bekleme yapmadan çömelmeye başlayın.\n" +
                "6.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
    ,arrayListOf("Ön Bacak"))

    val bacakContentLunge = ProgramContent(
        "Lunge",
        R.drawable.lunge,
        arrayListOf("spor salonu", "sadece dumbell", "evde ekipmansız"),
        "1.\tBu egzersizde nefes kontrolü tekrar sayısı açısından büyük önem taşımakta. İniş anında nefes alıp, kalkış anında nefes vereceksiniz.\n" +
                "2.\tNefes alın ve öne doğru bir adım atarak geride kalan ayağınızla dizinizin üstüne çökmeye başlayın.\n" +
                "3.\tDiziniz yere temas etmemeli. Temas etmesi işimizi ne kadar kolaylaştırsa da aslında hareketten çalmamıza neden oluyor. Bu nedenle bunu yapmayın. Zaman kaybından başka bir şey değil.\n" +
                "4.\tDizinizin üzerine çöktükten sonra nefes vererek kalkmaya başlayın ve geride kalan ayağınızı, ileride ki ayağınızın bir adım önüne atın. Ve tekrar nefes alarak çökmeye başlayın.\n" +
                "5.\tHareketi yaparken ilk başlarda denge sorunu yaşayacaksınız. Dengeyi öğrenebilmek için gerekirse ağırlıksız ya da düşük ağırlıklarla başlayın.\n" +
                "6.\tÜst vücudunuzu kesinlikle yere dik olarak tutun. Egzersiz boyunca sadece karşıya bakın. Yere bakmak dengenizi bozacaktır.\n"
        ,arrayListOf("Ön Bacak"))

    val bacakContentSquat = ProgramContent(
        "Dumbbell Squat",
        R.drawable.dumbbell_squat,
        arrayListOf("spor salonu", "sadece dumbell"),
        "1.\tEgzersizi ilk defa yapacaksanız düşük ağırlıkta iki adet dumbbell alın. Daha önce yaptıysanız ve gerekli güce ulaştıysanız set sonuna kadar ellerinizi yormayacak yani egzersizi yarıda bırakmanıza neden olmayacak ağırlıkta iki adet dumbbell alın.\n" +
                "2.\tAvuç içleriniz vücuda bakar halde olsun. Ayaklarınızı omuz genişliğinizden biraz daha fazla açın ve parmak uçlarınız karşıya baksın. Bu ayak genişliği iniş ve kalkış anında bacakların dumbbellar’a çarpmayacağı bir genişlik olmalı.\n" +
                "3.\tDik pozisyondayken nefes alarak çömelmeye başlayın. Kollar tüm hareket boyunca yere sarkık vaziyette olacak.\n" +
                "4.\tÜst bacağınız yani diz ve kalça arasında ki kısım yere paralel oluncaya kadar orta yavaş bir hızda çömelmenizi yapın. Göğsünüz dik ve başınız ileri bakar pozisyonda olsun. Üst gövdenizi yere eğmemeye çalışın.\n" +
                "5.\tSon noktaya vardığınızda beklemeden, nefes vererek orta hızda yükselmeye başlayın. Tepe noktaya ulaştığınızda yine beklemeden nefes alarak çömelin.\n" +
                "6.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Ön Bacak","Arka Bacak"))

    val bacakContentLeg = ProgramContent(
        "Leg Extension",
        R.drawable.leg,
        arrayListOf("spor salonu"),
        "1.\tMakineye oturmadan önce boyunuzun uzunluğuna göre oturma kısmını ayarlayın.\n" +
                "2.\tAyak pedini ayağınızın hemen üstüne yani bileğin başlangıcına ayarlayın. Uygun bir ağırlık seçin. Yüksek ağırlıklar, alt bacağınızı üst bacağınıza paralel olana kadar kaldırmanıza engel olabilir. Bu yüzden biraz daha düşük bir ağırlık tercih edilmeli.\n" +
                "3.\tSırtınızı tamamen yaslayın ve oturağın her iki yanında bulunan kolları kavrayın. Bu tutamaçlara asılmak ayak kaldırmanıza destek verecektir.\n" +
                "4.\tŞimdi nefes alın ve ardından nefes vererek ayaklarınızı yukarı doğru  orta hızda kaldırmaya başlayın.\n" +
                "5.\tYapabildiğiniz kadar alt ve üst bacağınızı paralel hale getirmeye çalışın. Olmuyorsa ağırlık düşürün. Bunu neden defalarca dile getirdiğimi de açıklayayım. Bacakları tam olarak kaldırmazsanız kas tam olarak yani sonuna kadar kendini çekemez. Maksimum mesafede çalışırsanız egzersizden alacağınız verim de artacaktır.\n" +
                "6.\tTepe noktaya ulaştıktan sonra nefes alarak yavaş hızda indirmeye  başlayın. Yavaş hızda indirmek de oldukça önemli. Yavaş indirirseniz üst bacak kasları ağırlığa direnç göstermek zorunda kalacağından iniş anında da çalışacaklardır.\n" +
                "7.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Ön Bacak"))

    val bacakContentPress = ProgramContent(
        "Leg press",
        R.drawable.leg_ress,
        arrayListOf("spor salonu"),
        "1.\tMakinenin sırt kısmını kendinize uygun açıya getirin. Göğüs kafesi büyük, göbek çevresi geniş ya da kalın bacaklara sahip olanlar olanlar sonuna kadar yatırabilirler. Bunun amacı, bacakları son noktaya kadar vücuda çekebilmek içindir.\n" +
                "2.\tUygun ağırlıkları takın ve makineye oturun. Ayaklarınız standart pozisyonda bir omuz genişliği kadar açık olmalı ve parmak uçları karşıya bakmalı.\n" +
                "3.\tAyaklarınızı itme yüzeyine sağlam bir şekilde konumlandırdıktan sonra biraz itip makinenin kilitlerini boşa çıkartın.\n" +
                "4.\tNefes alarak  dizlerinizi bükmeye başlayın ve ağırlığı kontrollü bir şekilde aşağı indirin. Sırtınız tamamen sehpaya dayalı olacak. Kesinlikle belinize ya da kalçanıza bir es vermeyin. Son noktaya kadar dizlerinizi kendinize doğru çekin. (Resim B)\n" +
                "5.\tNefes vererek ağırlığı yukarı doğru itmeye başlayın. Son noktaya geldiğinizde dizleriniz bir miktar kırık olmalı. Sonuna kadar açarsanız ve makine de çok yüksek bir ağırlık varsa diz kapağınız zarar görebilir. Bu riske girmeyin. (Resim A)\n" +
                "6.\tTepe noktasına ulaştığınızda 1 saniye kadar bekleyip nefes alarak ağırlığı tekrar aşağı indirin. Tekrar sayısı kadar yapıp seti tamamlayın ve makinenin kilitlerini kapatmayı unutmayın.\n"
        ,arrayListOf("Ön Bacak"))

    val bacakContentSquat1 = ProgramContent(
        "Squat",
        R.drawable.squat,
        arrayListOf("spor salonu"),
        "1.\tEğer fitness’a yeni başladıysanız ve ağırlıksız olarak ilk squatlarınızı başarıyla gerçekleştirdiyseniz, barbell kullanarak squat yapmanızın vakti gelmiş demektir.\n" +
                "2.\tBu hareketi yerden sırtınıza bir barbell alarak, serbest squat sehpahası‘nda ya da smith machine’de yapabilirsiniz.\n" +
                "3.\tBarı omzunuzun üzerine alırken, barın trapez kaslarının üstüne gelmesine dikkat edin. Bu sayede omzunuz acımaz ve harekete daha çok konsantre olursunuz.\n" +
                "4.\tEk olarak barın üzerine, eğer varsa ağırlık süngerini koyabilir ya da havlunuzu sarabilirsiniz.\n" +
                "5.\tŞimdi barı tamamen ortalayın. Her iki elinizle resimdeki gibi geniş tutuşla barı tutun ve dengenizi sağlayın.\n" +
                "6.\tAyaklarınızı bir omuz genişliği kadar açın ve parmak uçlarınızın tam karşıya bakmasına özen gösterin.\n" +
                "7.\tDerin bir nefes alın. Sırtınızı dik tutarak dizlerinizi bükün ve yere çömelmeye başlayın. Başınız her zaman karşıya bakmalı, yere ya da sağa sola bakmayın. Yoksa boyun sakatlığına maruz kalabilirsiniz.\n" +
                "8.\tYere dik durumda olan üst bacağınız yere paralel oluncaya kadar çömelin. Daha aşağıya inmemeye dikkat edin. Ardından nefes vererek yukarı doğru kalkmaya başlayın.\n" +
                "9.\tTekrar sayısı kadar yapın ve seti tamamlayın.\n"
        ,arrayListOf("Ön Bacak","Arka Bacak"))

    val bacakContentLegCurl = ProgramContent(
        "Leg Curl",
        R.drawable.lyin_leg_curl,
        arrayListOf("spor salonu"),
        "1.\tMakineye uzanmadan önce havlunuzu serin. Bir önce kalkan kişinin terine maruz kalmak ya da terinizi bırakmak istemezsiniz.\n" +
                "2.\tUygun bir ağırlık seçin ve makinenin pedlerini tam aşil tendonunun üzerine gelecek şekilde ayarlayın. Bu ayar kritik önem taşımakta. Ped ne kadar dize yakın olursa kaldıracağınız yük o kadar düşer. Aşil tendonu üstü ise en mükemmel yerdir.\n" +
                "3.\tBoyu uzun olan arkadaşlar biraz öne doğru gelip bu mesafeyi daha kolay ayarlayabilirler.\n" +
                "4.\tMakineye yüz üstü uzanın, ayaklarınızı pedlere dayayın, tutamaçları tutun (bu daha kolay bir kaldırış yapmanız için size destek sağlar) nefes alın ve ardından nefes vererek orta hızda bacaklarınızı geriye doğru bükün.\n" +
                "5.\tPedler kalçanıza değene kadar bunu yapın. Arka bacak kaslarınızın sonuna kadar çekiş yaptığını hissedin. Son noktaya geldiğinizde nefes alarak yavaş hızda ayaklarınızı salmaya başlayın.\n" +
                "6.\tTamamen saldığınızda bekleme yapmadan tekrar bacaklarınızı geriye doğru bükün.\n" +
                "7.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Ön Bacak","Arka Bacak") )

    val bacakContentLegSeated = ProgramContent(
        "Seated Leg Curl",
        R.drawable.seated_1,
        arrayListOf("spor salonu"),
        "1.\tÖncelikle makineye uygun bir ağırlık seçin. Yatarak yaptığınız arka bacak egzersizi ağırlığınızın yarısı başlangıç için uygun olacaktır.\n" +
                "2.\tMakinenin üst pedini dizin üst kısmına getirin ve sabitleyin. Alt pedi ise aşil tendonunun üzerine getirin. Boydan dolayı mesafeyi ayarlayamıyorsanız sehpayı geriye doğru çekin.\n" +
                "3.\tPozisyonunuzu aldıktan sonra her iki taraftaki tutamaçları kavrayıp güç alın. Nefes alın ve ardından nefes vererek orta hızda bacaklarınızı geriye doğru bükmeye başlayın.\n" +
                "4.\tSon mesafeye kadar bükün ve bir saniye kadar bekledikten sonra nefes alarak orta – yavaş hızda bacaklarınızı açmaya başlayın. Sonuna kadar açıldıktan sonra bekleme yapmadan tekrar bükmeye başlayın.\n" +
                "5.\tTekrar sayısı kadar yapıp setinizi tamamlayın.\n"
        ,arrayListOf("Arka Bacak"))

    val bacakContentLegBarbell = ProgramContent(
        "Barbell Lunge",
        R.drawable.barbell_lunge,
        arrayListOf("spor salonu"),
        "1.\tÖncelikle uygun ağırlıkta bir barbell’i sırtınıza alın. İlk denemeleriniz ise boş bar ile yapmanızda fayda var.\n" +
                "2.\tBarbell’i sırtınıza alacağınız nokta büyük önem taşımakta. Sonuçta her bir ayak için 10 toplamda 20 tekrar yapacaksınız ve bu uzun bir süre yüke maruz kalacağınız anlamına geliyor. Yüklenme noktası iyi ayarlandığında, barbell canınızı yakmadan sonuna kadar dayanabilirsiniz.\n" +
                "3.\t Örnekte görüldüğü üzere bu işin profesyonelleri tam bu noktayı kullanmakta. Trapez kasının üst kısmına ağırlık yerleştirilmiş. Yani yük omuz ya da ense üzerinde değil.\n" +
                "4.\tUygun ağırlık ve uygun yerleştirmek noktası ayarlandığına göre başlayabiliriz. Ayaklarınızı omuz genişliğiniz kadar yani ileriye rahat bir adım atacağınız kadar açık tutun. Ellerinizle barbell’i sıkıca kavrayın ve sağa sola devrilmesini önleyin.\n" +
                "5.\tİleriye doğru uzun bir adım atın, ileriye attığınız bacağınızın üst kısmı yere paralel olana kadar nefes alarak iniş yapın. Geride kalan bacağınızda ki diziniz yere değse dahi oradan ivme almamaya çalışın. İniş tamamlandıktan sonra nefes alarak ilerideki bacağınızla kendinizi yukarı doğru itmeye başlayın ve başlangıç pozisyonunuza dönün.\n" +
                "6.\tEgzersizin devamı için iki seçeceğiniz var. Ya sağ bacak, sol bacak olarak sırasıyla çalıştıracaksınız ya da 10 tekrar sağ bacak 10 tekrar sol bacak olarak çalıştıracaksınız. Tavsiyemiz ise şu şekilde olacak. Yeterli bacak gücüne sahip değilseniz bacaklarınızı sırasıyla çalıştırıp yeterli güce kavuştuktan sonra aralıksız 10’ar tekrar olarak uygulayın.\n" +
                "7.\t10 tekrar sağ,  10 tekrar sol  maksimum gelişim sağlayacaktır.  Tabi bunu yaparken set arası dinlenme gibi bir şey söz konusu değil. Her iki bacak da çalıştıktan sonra set arası uygulayabilirsiniz.\n"
        ,arrayListOf("Arka Bacak"))

    val bacakContentCalf = ProgramContent(
        "Calf Hareketi",
        R.drawable.kalf,
        arrayListOf("spor salonu", "sadece dumbell", "evde ekipmansız"),
        "1.\tUygun bir ağırlık seçin ve step tahtasının üzerine tek ayağınızın parmak uçlarını koyun. Step tahtası yok ise bir ağırlık plakası ya da bir merdiven basamağı ucu olabilir.\n" +
                "2.\tParmak uçlarınızı yerleştirdiniz ve ayağın ortası ve topuk bölgesi yere paralel olarak boşta kaldı. Bu başlangıç pozisyonunuz olacak.\n" +
                "3.\tDengeyi sağlamak için diğer elinizle bir yere tutunabilirsiniz ama bunu yaparken tutunduğunuz yerden güç almayın. Nefes alın ver ardından nefes vererek orta hızda yukarı doğru yükselin.Tepe noktaya ulaştığınızda iki saniye kadar bekleyin\n" +
                "4.\tArdından nefes alarak kalkış hızınıza oranla daha yavaş bir hızda inişe geçin. İniş noktası ise ayak yere paralel başlangıç noktasına göre daha aşağıda olacak. Bunu maksimum mesafede çalışabilmek için yapacağız.\n" +
                "5.\tİnebildiğiniz kadar aşağı indikten sonra yine nefes vererek tepe noktaya kadar kendinizi yükseltin.\n" +
                "6.\tTekrar sayısı kadar yapıp diğer ayağa geçin ve seti tamamlayın.\n"
        ,arrayListOf("Arka Bacak"))

    val bacakContentRaise = ProgramContent(
        "Seated Calf Raise",
        R.drawable.calf_seat,
        arrayListOf("spor salonu"),
        "1.\tMakineye uygun ağırlıkta plakaları takın. Oturarak yapıldığı için ağır plakalar rahatlıkla kaldırılabilir.\n" +
                "2.\tParmak uçlarınızı makinenin ayaklığına yerleştirin. Topuğunuzla yükselip makinenin kilidini boşa çıkartın.\n" +
                "3.\tArdından nefes alarak inişe başlayın. Yavaş bir hızda aşağı doğru için ve ayak topuklarınızı, sonuna kadar aşağı indirin.\n" +
                "4.\tNefes vererek topuklarınızı yükseltmeye başlayın. Tepe noktaya kadar ulaştığınızda iki saniye kadar bekleyin ve ardından tekrar inişe geçin.\n"
        ,arrayListOf("Arka Bacak"))

    val bacakContentStanding  = ProgramContent(
        "Standing Machine Calf Raises",
        R.drawable.standing,
        arrayListOf("spor salonu"),
        "1.\tResimde de görüldüğü gibi bacaklarınızı omuz genişliğiniz kadar açık halde makinenin sehpasına basın. Parmak uçlarınız tam karşıya baksın. Calf kasının her üç parçasını da aynı anda çalıştırmanız için bu önemli.\n" +
                "2.\tUygun bir ağırlık seçin. En azından vücut ağırlığınızın 4/1 i kadar bir ağırlık olabilir. İlk denemelerde aşil tendonunuzu fazla zorlamamak için bu ağırlıktan başlayabilirsiniz. Zamanla arttırın.\n" +
                "3.\tKalf kasları ilk adımlarımızdan beri bizleri taşıdıkları için yüksek ağırlıklara çabuk alışacaklardır.\n" +
                "4.\tŞimdi ağırlığa yüklenin ve dizlerinizi kırmadan (bu da püf noktalardan biridir. Dizleri kırarsanız tekrar sayınız artar fakat tam gelişim elde edemezsiniz. Egzersiz boyunca dizleri kırmamaya dikkat edin) parmak uçlarınızda yükselebildiğiniz kadar topuğunuzu yükseltin.\n" +
                "5.\tSon noktaya geldiğinizde bekleme yapmadan inmeye başlayın topuğunuz parmak uçları seviyenizden daha aşağı inmeli ki hareketin mesafesini artırabilesiniz. Bu sayede kaslarda ki yırtılma ve gelişim daha fazla olacaktır.\n" +
                "6.\tSon noktaya kadar indikten sonra bekleme yapmadan tekrar yukarı doğru yükselin.\n"
        ,arrayListOf("Arka Bacak"))

    bacakContentList.add(bacakContentGoblet)
    bacakContentList.add(bacakContentLunge)
    bacakContentList.add(bacakContentSquat)
    bacakContentList.add(bacakContentLeg)
    bacakContentList.add(bacakContentPress)
    bacakContentList.add(bacakContentSquat1)
    bacakContentList.add(bacakContentLegCurl)
    bacakContentList.add(bacakContentLegSeated)
    bacakContentList.add(bacakContentLegBarbell)
    bacakContentList.add(bacakContentCalf)
    bacakContentList.add(bacakContentRaise)
    bacakContentList.add(bacakContentStanding)

    val karinContentList = arrayListOf<ProgramContent>()

    val karinContentMountain   = ProgramContent(
        "Mountain Climber",
        R.drawable.mountain_climber,
        arrayListOf("spor salonu","evde ekipmansız"),
        "1.\tŞınav ya da klasik plank pozisyonunda harekete başlanır. Eğer karın kısmını izole çalıştırmak istiyorsanız plank, gelişime omuz, arka kol ve ön kol da dahil olsun istiyorsanız şınav pozisyonunu tercih edin.\n" +
                "2.\tPozisyonunuzu belirledikten sonra bir ayağınızı yukarı yani yan karına doğru çekmeye başlayın. Bunu yaparken yan karın kaslarınıza iyice konsantre olun. Onları sıkıştırın.\n" +
                "3.\tAyağınız maksimum ölçüde yukarıya kadar geldikten ve yan karnınızı sıkıştırdıktan sonra geriye doğru itin ve diğer ayağınızı çekmeye başlayın. Aynı işlemleri ona da uygulayın.\n" +
                "4.\tNefes kontrolü ise; çekiş anında nefes vermek, itiş anında nefes almak tekrar sayınızı arttıracaktır.\n"
        , arrayListOf("Karın"))

    val karinContentPlank    = ProgramContent(
        "Plank Hareketi",
        R.drawable.duz_plank,
        arrayListOf("spor salonu","evde ekipmansız"),
        "1.\tYüz üstü yere uzanın.\n" +
                "2.\tTopuktan enseye kadar vücudunuz düz bir çizgi halinde olmalı.\n" +
                "3.\tDirsekleriniz ileriye doğru ve yere tam temas halinde olsun. Üst kol ise yere dik olacak.\n" +
                "4.\tNefes alın ve süreyi başlatın.\n" +
                "5.\tHareket boyunca karın kaslarınızı sonuna kadar kasın. Bölgede mükemmel bir yanma hissi duyuncaya kadar devam edin.\n" +
                "6.\tGücünüzün tamamı tükenince hareketi bırakın.\n"
    ,arrayListOf("Karın"))

    val karinContentMekik    = ProgramContent(
        "Mekik",
        R.drawable.mekik,
        arrayListOf("spor salonu","evde ekipmansız"),
        "1.\tYere uzanın. Ayaklarınızı tamamen uzatabilir ya da dizlerinizden kırabilirsiniz. Bana inanın, bunu yapmak  egzersizi ne zorlaştırır ne de kolaylaştırır. Yıllarca dizleri kırarak yapılan mekiği yarım mekik olarak saydık ama alakası yok. Devam edelim.\n" +
                "2.\tDizleriniz kırmanızı tavsiye ediyorum. Bu şekilde karın kaslarınıza daha çok konsantre olabilirsiniz. Ellerinizi başınızın arkasına ya da yanına koyabilirsiniz.\n" +
                "3.\t Nefes kontrolü bu egzersizde çok önemlidir. Kalkış anında nefes verecek iniş anında nefes alacaksınız. Nefesi burundan alıp ağızdan vermek tekrar sayısına büyük bir etki etmekte. Her antrenman sonrası mekik çeken biri olarak bunu söylüyorum. Nefes alın ve ardından nefes vererek kalkışa başlayın.\n" +
                "4.\tEn önemli püf noktayı söylüyorum. Bu kalkışı yaparken sadece 20 cm gibi bir mesafe hareket edeceksiniz. Sadece ama sadece karın kasınızı kullanarak bunu yapacaksınız.\n"
        ,arrayListOf("Karın"))

    val karinContentLeg     = ProgramContent(
        "Mekik",
        R.drawable.leg_rais,
        arrayListOf("spor salonu","evde ekipmansız"),
        "1.\tİlk iki varyasyonun aksine bu egzersizde ayaklar hiç kırılmadan karşıya uzatılır. Yapması oldukça zordur. Karın kaslarına mükemmel bir yanma hissi verir.\n" +
                "2.\tHareket yavaş yapıldığı taktirde negatif kasılmaları kullanarak yan karın kaslarını da çalıştırmış olursunuz.\n" +
                "3.\tNefes alın ve ardından nefes vererek her iki ayağınızı da aynı anda yere paralel oluncaya kadar kaldırın.\n" +
                "4.\tSon noktaya geldiğinizde bir saniye kadar bekleyin ve ardından kaldırış hızınıza oranla daha yavaş bir hızda nefes alarak bacaklarınızı aşağı salın.\n" +
                "5.\tTamamen indiklerinde bekleme yapmadan nefes vererek tekrar kaldırın.\n"
        ,arrayListOf("Karın"))

    karinContentList.add(karinContentMountain)
    karinContentList.add(karinContentPlank)
    karinContentList.add(karinContentMekik)
    karinContentList.add(karinContentLeg)


    val programOmuz = Program(0, "Omuz", R.drawable.omuz, omuzContentList)
    val programSirt = Program(1, "Sırt", R.drawable.sirt, sirtContentList)
    val programGogus = Program(2, "Göğüs", R.drawable.gogus, gogusContentList)
    val programBiceps = Program(3, "Biceps (Ön kol)", R.drawable.on_kol, onKolContentList)
    val programTriceps = Program(4, "Triceps (Arka kol)", R.drawable.arka_kol, arkaKolContentList)
    val programBacak = Program(5, "Bacak", R.drawable.bacak, bacakContentList)
    val programKarin = Program(6, "Karın", R.drawable.karin, karinContentList)
    val program = Program(7, "Program", R.drawable.program, emptyList())


    val programList = arrayListOf<Program>()

    programList.add(programOmuz)
    programList.add(programSirt)
    programList.add(programGogus)
    programList.add(programBiceps)
    programList.add(programTriceps)
    programList.add(programBacak)
    programList.add(programKarin)
    programList.add(program)


    return programList
}



