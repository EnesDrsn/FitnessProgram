package com.example.fitnessprogram.model

import android.graphics.drawable.Drawable
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
data class ProgramContent(
    val contentName: String,
    val contentImage: Int,
    val contentCategory: List<String>,
    val contentDetail: String,
    val programCategory: List<String>
): Parcelable
