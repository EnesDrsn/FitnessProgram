package com.example.fitnessprogram.db

import android.content.Context
import androidx.room.*
import com.example.fitnessprogram.model.Program


@Database(entities = [Program::class], version = 2)

@TypeConverters(ArrayListConverter::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null
        private val LOCK = Any()

        operator fun invoke(context: Context) = instance ?: synchronized(LOCK) {
            instance ?: createDatabase(context).also {
                instance = it
            }
        }

        private fun createDatabase(context: Context) =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "app_db"
            ).allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build()
    }

}