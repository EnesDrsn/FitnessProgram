package com.example.fitnessprogram.db

import androidx.room.TypeConverter
import com.example.fitnessprogram.model.Program
import com.example.fitnessprogram.model.ProgramContent
import com.google.gson.Gson


class ArrayListConverter {

    @TypeConverter
    fun listToJson(value: List<Program>?) = Gson().toJson(value)

    @TypeConverter
    fun jsonToList(value: String) = Gson().fromJson(value, Array<Program>::class.java).toList()

    @TypeConverter
    fun listToJson1(value: List<ProgramContent>?) = Gson().toJson(value)

    @TypeConverter
    fun jsonToList1(value: String) = Gson().fromJson(value, Array<ProgramContent>::class.java).toList()


}