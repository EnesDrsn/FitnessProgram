package com.example.fitnessprogram

import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnessprogram.databinding.ActivityCreateProgramBinding
import com.example.fitnessprogram.db.AppDatabase
import com.example.fitnessprogram.model.ProgramContent
import java.lang.String


class CreateProgramActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateProgramBinding
    private lateinit var appDatabase: AppDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateProgramBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appDatabase = AppDatabase(this)

        binding.imageViewBack.setOnClickListener {
            finish()
        }

        val randomProgram = arrayListOf<ProgramContent>()
        binding.buttonCreateProgram.setOnClickListener {


            val omuzCheck = binding.checkBoxOmuz.isChecked
            val sirtCheck = binding.checkBoxSirt.isChecked
            val gogusCheck = binding.checkBoxGogus.isChecked
            val bicepsCheck = binding.checkBoxBiceps.isChecked
            val tricepsCheck = binding.checkBoxTriceps.isChecked
            val bacakCheck = binding.checkBoxBacak.isChecked
            val karinCheck = binding.checkBoxKarin.isChecked


            val sporCheck = binding.checkBoxCategorySpor.isChecked
            val dumbellCheck = binding.checkBoxCategoryDumbell.isChecked
            val ekipmansizCheck = binding.checkBoxCategoryEkipmansiz.isChecked



            if (omuzCheck) {
                val content = appDatabase.appDao().getQueryProgram("Omuz").content.filter {
                    it.programCategory.contains("Ön Omuz")
                }.random()
                val content1 = appDatabase.appDao().getQueryProgram("Omuz").content.filter {
                    it.programCategory.contains("Arka Omuz")
                }.random()
                val content2 = appDatabase.appDao().getQueryProgram("Omuz").content.filter {
                    it.programCategory.contains("Orta Omuz")
                }.random()
                randomProgram.add(content)
                randomProgram.add(content1)
                randomProgram.add(content2)


            }

            if (sirtCheck) {
                val content = appDatabase.appDao().getQueryProgram("Sırt").content.filter {
                    it.programCategory.contains("Trapez")
                }.random()
                val content1 = appDatabase.appDao().getQueryProgram("Sırt").content.filter {
                    it.programCategory.contains("Orta Sırt")
                }.random()
                val content2 = appDatabase.appDao().getQueryProgram("Sırt").content.filter {
                    it.programCategory.contains("Bel")
                }.random()
                val content3 = appDatabase.appDao().getQueryProgram("Sırt").content.filter {
                    it.programCategory.contains("Kanat")
                }.random()
                randomProgram.add(content)
                randomProgram.add(content1)
                randomProgram.add(content2)
                randomProgram.add(content3)
            }

            if (gogusCheck) {
                val content = appDatabase.appDao().getQueryProgram("Göğüs").content.filter {
                    it.programCategory.contains("Üst Göğüs")
                }.random()
                val content1 = appDatabase.appDao().getQueryProgram("Göğüs").content.filter {
                    it.programCategory.contains("Alt Göğüs")
                }.random()
                val content2 = appDatabase.appDao().getQueryProgram("Göğüs").content.filter {
                    it.programCategory.contains("İç Göğüs")
                }.random()
                randomProgram.add(content)
                randomProgram.add(content1)
                randomProgram.add(content2)
            }

            if (bicepsCheck) {
                val content =
                    appDatabase.appDao().getQueryProgram("Biceps (Ön kol)").content.filter {
                        it.programCategory.contains("Ön Kol")
                    }.random()
                randomProgram.add(content)
            }

            if (tricepsCheck) {
                val content =
                    appDatabase.appDao().getQueryProgram("Triceps (Arka kol)").content.filter {
                        it.programCategory.contains("Arka Kol")
                    }.random()
                randomProgram.add(content)
            }

            if (bacakCheck) {
                val content = appDatabase.appDao().getQueryProgram("Bacak").content.filter {
                    it.programCategory.contains("Ön Bacak")
                }.random()
                val content1 = appDatabase.appDao().getQueryProgram("Bacak").content.filter {
                    it.programCategory.contains("Arka Bacak")
                }.random()
                randomProgram.add(content)
                randomProgram.add(content1)
            }

            if (karinCheck) {
                val content = appDatabase.appDao().getQueryProgram("Karın").content.filter {
                    it.programCategory.contains("Karın")
                }.random()
                randomProgram.add(content)
            }

            val sporList = arrayListOf<ProgramContent>()
            if (sporCheck) {

                appDatabase.appDao().getAllProgram().forEach {
                    val content = it.content.filter {
                        it.contentCategory.contains("spor salonu")
                    }
                    sporList.addAll(content)
                }
                val randomContent = sporList.random()
                randomProgram.add(randomContent)
            }

            val dumbellList = arrayListOf<ProgramContent>()
            if (dumbellCheck) {

                appDatabase.appDao().getAllProgram().forEach {
                    val content = it.content.filter {
                        it.contentCategory.contains("sadece dumbell")
                    }
                    dumbellList.addAll(content)
                }
                val randomContent = dumbellList.random()
                randomProgram.add(randomContent)
            }

            val ekipmansizList = arrayListOf<ProgramContent>()
            if (ekipmansizCheck) {

                appDatabase.appDao().getAllProgram().forEach {
                    val content = it.content.filter {
                        it.contentCategory.contains("evde ekipmansız")
                    }
                    ekipmansizList.addAll(content)
                }
                val randomContent = ekipmansizList.random()
                randomProgram.add(randomContent)
            }


            val programNameList = arrayListOf<kotlin.String>()
            randomProgram.forEach {
                programNameList.add(it.contentName)
            }


            val alertDialog = AlertDialog.Builder(this, R.style.DialogTheme)
            val alert = alertDialog.create()

            val view = LayoutInflater.from(this).inflate(R.layout.alert_result_program, null)

            val listViewProgram = view.findViewById<ListView>(R.id.listViewProgram)

            val listAdapter = ArrayAdapter<kotlin.String>(
                this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                programNameList
            )

            alert.setView(view)

            listViewProgram.adapter = listAdapter


            randomProgram.clear()
            binding.checkBoxOmuz.isChecked = false
            binding.checkBoxSirt.isChecked = false
            binding.checkBoxGogus.isChecked = false
            binding.checkBoxBiceps.isChecked = false
            binding.checkBoxTriceps.isChecked = false
            binding.checkBoxBacak.isChecked = false
            binding.checkBoxKarin.isChecked = false
            binding.checkBoxCategorySpor.isChecked = false
            binding.checkBoxCategoryDumbell.isChecked = false
            binding.checkBoxCategoryEkipmansiz.isChecked = false

            alert.show()


        }

    }
}